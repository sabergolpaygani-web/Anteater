# Global Spot Accumulation 13.0

Primary metric: **Daily Buy**. Secondary metric: **3D / 5D / 7D**.

Daily Buy is kept in its own UI field and is not averaged into the multi-day section.

Implemented Spot market sources:
- Binance Spot
- MEXC Spot
- OKX Spot
- Bybit Spot
- Bitget Spot
- Gate.io Spot
- CoinEx Spot

DEX:
- GeckoTerminal public on-chain data is queried separately for top pools matching the searched symbol when the API returns identifiable buy/swap data. DEX is kept separate from CEX and is only added to TOTAL when a usable DEX result is returned.

Rules:
- Spot only; no futures/perpetual/options.
- Buy-side data is preferred; sources without reliable buy/sell identification are not silently converted from total volume.
- Circulating supply from CoinMarketCap is the denominator.
- Daily CEX coverage can differ by exchange because public endpoints expose different historical depths/rate limits; the app reports returned source counts instead of pretending coverage is complete.
- Taker-buy volume is a demand-side proxy, not proof of net new capital or long-term holding.

CoinGlass is not required.

## v13.1 no-key supply fallback anomaly indicator
- Added a per-token relative anomaly indicator for Daily Buy.
- It compares today's Buy/Supply intensity with the token's own recent daily baseline inferred from the 3D/5D/7D windows.
- It does not use a fixed Buy/Supply threshold and does not suppress signals; it reports how many times today's buy rate exceeds the recent baseline and the percentage deviation.
- Fixed duplicate current-day additions in the MEXC and OKX aggregation paths.
