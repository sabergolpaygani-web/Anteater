ANTEATER 13.1 - CLOUD APK BUILD

This package is prepared for a cloud Android build.
No Android Studio or Python is required on your computer.

The included GitHub Actions workflow builds:
app/build/outputs/apk/debug/app-debug.apk

How to use:
1. Create a GitHub repository.
2. Upload the CONTENTS of this project folder (not the outer folder itself).
3. Open the repository's Actions tab.
4. Select "Build Anteater APK" and run it.
5. Open the completed workflow run.
6. Download the artifact named "Anteater-13.1-debug-apk".
7. Extract it and install app-debug.apk on Android.

No app logic was intentionally changed; this package only adds the cloud-build workflow and instructions.
