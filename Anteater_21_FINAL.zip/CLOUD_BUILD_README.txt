Anteater 20.1 FIXED

This package fixes the background scan scheduling bug.
The foreground service now waits for the actual auto-scan Job to finish before starting the configured interval timer.

Build with the included GitHub Actions workflow.
Default interval: 5 minutes. Supported manual interval: 1-60 minutes.
