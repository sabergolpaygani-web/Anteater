# Anteater

Single-source Android Spot accumulation scanner.

## v23 build contract
- App label: Anteater
- Primary signal: Net Spot Accumulation
- Auto scan: enabled by default, configurable 1–60 minutes
- Background scan: foreground service
- Restart recovery: BOOT_COMPLETED and package-replaced receiver
- Spot only; derivatives excluded
- Circulating supply is the primary denominator
- No fixed buy/supply threshold is used as a hard filter

The repository should contain only the current `Anteater_23_FINAL.zip` source package and this build workflow. Old Anteater ZIPs and old build workflows should be removed before the release build.
