Anteater v23

Upload Anteater_23_FINAL.zip and .github/workflows/build-apk.yml to the clean GitHub repository.
The workflow builds only Anteater_23_FINAL.zip, verifies the APK identity (package, version and label), uploads an Actions artifact, and creates a GitHub Release.
