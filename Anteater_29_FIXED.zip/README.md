# Anteater v29

Technical correction release based on the Atom review.

- Scanner/network logic is separated from the Compose ViewModel in `ScanRepository`.
- Foreground service no longer creates a ViewModel or launches `viewModelScope`.
- Boot receiver auto-start of a `dataSync` foreground service was removed because modern Android restricts this path.
- CMC API key is stored with Android Keystore AES/GCM instead of plaintext SharedPreferences.
- Global scan uses a bounded concurrency gate and an atomic progress counter.
- Recent-only Bybit/Bitget feeds are not presented as verified 24h totals.
- CoinEx buy-only ticker is not used to manufacture a Sell=0 net signal.
- Gate.io uses a time-bounded, paginated 24h query.
- DEX directional data is excluded until the pool token identity is positively verified.
- TradingView links are clickable in the UI and notification.
- Auto-scan results use LazyColumn `items(...)` instead of eager `forEachIndexed` rendering.
