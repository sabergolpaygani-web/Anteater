package com.example.spotvolume

import android.content.Context
import com.google.gson.JsonElement
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * Network/scanning layer. It deliberately has no ViewModel or Compose state.
 * This makes it safe to use from the foreground service and from UI jobs.
 */
object ScanCoordinator { val mutex = Mutex() }

class ScanRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("spot_volume", 0)

    private val cmc = retrofit("https://pro-api.coinmarketcap.com/").create(CmcApi::class.java)
    private val paprika = retrofit("https://api.coinpaprika.com/").create(PaprikaApi::class.java)
    private val coinGecko = retrofit("https://api.coingecko.com/").create(CoinGeckoApi::class.java)
    private val binance = retrofit("https://data-api.binance.vision/").create(BinanceApi::class.java)
    private val mexc = retrofit("https://api.mexc.com/").create(MexcApi::class.java)
    private val okx = retrofit("https://www.okx.com/").create(OkxApi::class.java)
    private val bybit = retrofit("https://api.bybit.com/").create(BybitApi::class.java)
    private val bitget = retrofit("https://api.bitget.com/").create(BitgetApi::class.java)
    private val gate = retrofit("https://api.gateio.ws/").create(GateApi::class.java)
    private val coinex = retrofit("https://api.coinex.com/").create(CoinExApi::class.java)
    private val gemini = retrofit("https://api.gemini.com/").create(GeminiApi::class.java)
    private val bitfinex = retrofit("https://api-pub.bitfinex.com/").create(BitfinexApi::class.java)
    private val bitfinexSymbols = retrofit("https://api.bitfinex.com/").create(BitfinexSymbolsApi::class.java)
    private val gecko = retrofit("https://api.geckoterminal.com/").create(GeckoApi::class.java)

    @Volatile private var cachedBinanceInfo: BinanceExchangeInfo? = null
    @Volatile private var cachedMexcInfo: MexcExchangeInfo? = null
    @Volatile private var cachedOkxInfo: OkxInstrumentsResponse? = null
    @Volatile private var cachedBitgetInfo: BitgetInstrumentsResponse? = null
    @Volatile private var cachedGatePairs: List<GatePair>? = null
    @Volatile private var cachedCoinExMarkets: CoinExMarketsResponse? = null
    @Volatile private var cachedGeminiSymbols: List<String>? = null
    @Volatile private var cachedBitfinexPairs: List<String>? = null

    private fun retrofit(base: String) = Retrofit.Builder()
        .baseUrl(base)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private suspend fun getBinanceInfo() = cachedBinanceInfo ?: binance.exchangeInfo().also { cachedBinanceInfo = it }
    private suspend fun getMexcInfo() = cachedMexcInfo ?: mexc.exchangeInfo().also { cachedMexcInfo = it }
    private suspend fun getOkxInfo() = cachedOkxInfo ?: okx.instruments("SPOT").also { cachedOkxInfo = it }
    private suspend fun getBitgetInfo() = cachedBitgetInfo ?: bitget.instruments("SPOT").also { cachedBitgetInfo = it }
    private suspend fun getGatePairs() = cachedGatePairs ?: gate.currencyPairs().also { cachedGatePairs = it }
    private suspend fun getCoinExMarkets() = cachedCoinExMarkets ?: coinex.marketList().also { cachedCoinExMarkets = it }
    private suspend fun getGeminiSymbols() = cachedGeminiSymbols ?: gemini.symbols().also { cachedGeminiSymbols = it }
    private suspend fun getBitfinexPairs(): List<String> = cachedBitfinexPairs ?: runCatching {
        bitfinexSymbols.symbols().filter { it.startsWith("t", true) }.also { cachedBitfinexPairs = it }
    }.getOrDefault(emptyList())

    suspend fun scanGlobal(onProgress: suspend (checked: Int, total: Int) -> Unit): List<AutoScanRow> = ScanCoordinator.mutex.withLock { coroutineScope {
        val meta = listOf(
            async { runCatching { getBinanceInfo() }.getOrNull() },
            async { runCatching { getMexcInfo() }.getOrNull() },
            async { runCatching { getOkxInfo() }.getOrNull() },
            async { runCatching { getBitgetInfo() }.getOrNull() },
            async { runCatching { getGatePairs() }.getOrNull() },
            async { runCatching { getCoinExMarkets() }.getOrNull() }
        ).awaitAll()

        val universe = linkedSetOf<String>()
        (meta[0] as? BinanceExchangeInfo)?.symbols.orEmpty()
            .filter { it.status.equals("TRADING", true) && stableQuotes.contains(it.quoteAsset?.uppercase(Locale.US)) }
            .mapNotNull { it.baseAsset?.uppercase(Locale.US) }.forEach { if (it.isNotBlank()) universe += it }
        (meta[1] as? MexcExchangeInfo)?.symbols.orEmpty()
            .filter { (it.status.equals("ENABLED", true) || it.status.equals("TRADING", true)) && stableQuotes.contains(it.quoteAsset?.uppercase(Locale.US)) }
            .mapNotNull { it.baseAsset?.uppercase(Locale.US) }.forEach { if (it.isNotBlank()) universe += it }
        (meta[2] as? OkxInstrumentsResponse)?.data.orEmpty()
            .filter { it.state.equals("live", true) && stableQuotes.contains(it.quoteCcy?.uppercase(Locale.US)) }
            .mapNotNull { it.baseCcy?.uppercase(Locale.US) }.forEach { if (it.isNotBlank()) universe += it }
        (meta[3] as? BitgetInstrumentsResponse)?.data.orEmpty()
            .filter { stableQuotes.contains(it.quoteCoin?.uppercase(Locale.US)) && !it.status.equals("offline", true) }
            .mapNotNull { it.baseCoin?.uppercase(Locale.US) }.forEach { if (it.isNotBlank()) universe += it }
        (meta[4] as? List<*>)?.mapNotNull { it as? GatePair }
            .orEmpty().filter { stableQuotes.contains(it.quote?.uppercase(Locale.US)) }
            .mapNotNull { it.base?.uppercase(Locale.US) }.forEach { if (it.isNotBlank()) universe += it }
        (meta[5] as? CoinExMarketsResponse)?.data.orEmpty()
            .filter { stableQuotes.contains(it.quote_ccy?.uppercase(Locale.US)) }
            .mapNotNull { it.base_ccy?.uppercase(Locale.US) }.forEach { if (it.isNotBlank()) universe += it }
        runCatching { getGeminiSymbols() }.getOrDefault(emptyList()).forEach { symbol ->
            val u = symbol.uppercase(Locale.US)
            val quote = when { u.endsWith("USDT") -> "USDT"; u.endsWith("USD") -> "USD"; else -> null }
            if (quote != null) {
                val base = u.removeSuffix(quote)
                if (base.isNotBlank()) universe += base
            }
        }
        runCatching { getBitfinexPairs() }.getOrDefault(emptyList()).forEach { symbol ->
            val u = symbol.uppercase(Locale.US).removePrefix("T")
            val quote = when { u.endsWith("USD") -> "USD"; u.endsWith("UST") -> "UST"; else -> null }
            if (quote != null) {
                val base = u.removeSuffix(quote)
                if (base.isNotBlank() && quote == "USD") universe += base
            }
        }

        if (universe.isEmpty()) throw IllegalStateException("Global Spot universe unavailable")

        val supplyMap = runCatching {
            paprika.tickers("USD", 0).mapNotNull { t ->
                val symbol = t.symbol?.uppercase(Locale.US)
                val supply = t.circulatingSupply
                if (symbol != null && supply != null && supply > 0.0) symbol to supply else null
            }.toMap()
        }.getOrDefault(emptyMap())

        // A bounded gate prevents a global scan from creating thousands of simultaneous HTTP calls.
        val gate = Semaphore(3)
        val checked = AtomicInteger(0)
        val total = universe.size
        val rows = universe.toList().map { coin ->
            async {
                gate.withPermit {
                    val n = checked.incrementAndGet()
                    if (n == 1 || n % 25 == 0 || n == total) onProgress(n, total)
                    val supply = supplyMap[coin] ?: runCatching { loadSupply(coin) }.getOrNull()
                    if (supply == null || supply <= 0.0) return@withPermit null
                    runCatching { scanNetAcrossSources(coin, supply) }.getOrNull()?.takeIf { it.net > 0.0 }
                }
            }
        }.awaitAll().filterNotNull()

        rows.sortedByDescending { it.ratioPct }
    } }

    private suspend fun loadSupply(coin: String): Double? {
        // CMC key is stored encrypted and is optional. Public sources remain the fallback.
        val key = SecretStore.get(context, "cmc_api_key").orEmpty()
        if (key.isNotBlank()) {
            val asset = runCatching { cmc.info(coin, key) }.getOrNull()
                ?.data?.firstOrNull { it.symbol.equals(coin, true) }
            if (asset?.circulatingSupply != null && asset.circulatingSupply > 0.0) return asset.circulatingSupply
        }
        runCatching {
            val match = paprika.search(coin).currencies.orEmpty().firstOrNull { it.symbol.equals(coin, true) }
            val id = match?.id ?: return@runCatching null
            paprika.coin(id).circulatingSupply?.takeIf { it > 0.0 }
        }.getOrNull()?.let { return it }
        return runCatching {
            val exact = coinGecko.search(coin).coins.orEmpty()
                .filter { it.symbol.equals(coin, true) }
                .sortedWith(compareBy<GeckoCoin> { it.marketCapRank ?: Int.MAX_VALUE }.thenBy { it.id ?: "" })
                .firstOrNull() ?: return@runCatching null
            coinGecko.coin(exact.id ?: return@runCatching null).marketData?.circulatingSupply?.takeIf { it > 0.0 }
        }.getOrNull()
    }

    private suspend fun scanNetAcrossSources(coin: String, supply: Double): AutoScanRow? {
        var buy = 0.0
        var sell = 0.0
        val names = mutableListOf<String>()

        suspend fun add(name: String, block: suspend () -> Pair<Double, Double>?) {
            val r = runCatching { block() }.getOrNull() ?: return
            buy += r.first
            sell += r.second
            names += name
        }

        add("Binance") { loadBinanceNet(coin) }
        add("MEXC") { loadMexcNet(coin) }
        add("OKX") { loadOkxNet(coin) }
        add("Gate.io") { loadGateNet(coin) }
        add("Gemini") { loadGeminiNet(coin) }
        add("Bitfinex") { loadBitfinexNet(coin) }

        // CoinEx public ticker exposes buy volume but not a matching sell volume.
        // It must therefore NOT be used in a Buy-Sell net calculation.

        // DEX direction is intentionally excluded until the token address in the pool
        // is positively identified. Counting a generic to_token_amount would be wrong.

        val net = buy - sell
        if (names.isEmpty() || net <= 0.0 || supply <= 0.0) return null
        val ratio = net / supply * 100.0
        val tv = tradingViewUrl(coin, names.firstOrNull())
        return AutoScanRow(coin, buy, sell, net, supply, ratio, names.joinToString(", "), tv)
    }

    private suspend fun loadBinanceNet(coin: String): Pair<Double, Double>? {
        val pairs = getBinanceInfo().symbols.orEmpty()
            .filter { it.status.equals("TRADING", true) && it.baseAsset.equals(coin, true) && stableQuotes.contains(it.quoteAsset?.uppercase(Locale.US)) }
            .mapNotNull { it.symbol }.distinct()
        var buy = 0.0; var sell = 0.0; var valid = false
        for (pair in pairs) {
            val row = runCatching { binance.klines(pair, "1d", 1).lastOrNull() }.getOrNull() ?: continue
            val total = row.getOrNull(5)?.asString?.toDoubleOrNull()
            val takerBuy = row.getOrNull(9)?.asString?.toDoubleOrNull()
            if (total != null && takerBuy != null && total >= takerBuy && total >= 0.0) {
                buy += takerBuy; sell += total - takerBuy; valid = true
            }
        }
        return if (valid) buy to sell else null
    }

    private suspend fun loadMexcNet(coin: String): Pair<Double, Double>? {
        val pairs = getMexcInfo().symbols.orEmpty()
            .filter { (it.status.equals("ENABLED", true) || it.status.equals("TRADING", true)) && it.baseAsset.equals(coin, true) && stableQuotes.contains(it.quoteAsset?.uppercase(Locale.US)) }
            .mapNotNull { it.symbol }.distinct()
        val now = System.currentTimeMillis()
        val since = now - 86_400_000L
        var buy = 0.0; var sell = 0.0; var validPairs = 0
        for (pair in pairs) {
            var cursor = since
            var complete = true
            var had = false
            while (cursor < now) {
                val end = minOf(now, cursor + 6L * 60L * 60L * 1000L)
                var fromId: Long? = null
                var pages = 0
                var windowDone = false
                while (!windowDone) {
                    if (++pages > 100) { complete = false; break }
                    val rows = runCatching {
                        mexc.aggTrades(pair, if (fromId == null) cursor else null, if (fromId == null) end else null, fromId, 1000)
                    }.getOrNull().orEmpty()
                    if (rows.isEmpty()) { windowDone = true; break }
                    for (r in rows) {
                        if (r.size < 7) continue
                        val ts = r[5].asLong
                        val qty = r[4].asString.toDoubleOrNull() ?: continue
                        if (ts < since || ts >= now || qty < 0.0 || !qty.isFinite()) continue
                        if (!r[6].asBoolean) buy += qty else sell += qty
                        had = true
                    }
                    val lastTs = rows.maxOfOrNull { it[5].asLong } ?: end
                    val lastId = rows.maxOfOrNull { it[0].asLong }
                    if (lastTs >= end || rows.size < 1000) windowDone = true
                    else fromId = (lastId ?: Long.MAX_VALUE) + 1L
                }
                if (!complete) break
                cursor = end + 1L
            }
            if (complete && had) validPairs++
        }
        return if (validPairs > 0) buy to sell else null
    }

    private suspend fun loadOkxNet(coin: String): Pair<Double, Double>? {
        val pairs = getOkxInfo().data.orEmpty()
            .filter { it.state.equals("live", true) && it.baseCcy.equals(coin, true) && stableQuotes.contains(it.quoteCcy?.uppercase(Locale.US)) }
            .mapNotNull { it.instId }.distinct()
        val cutoff = System.currentTimeMillis() - 86_400_000L
        var buy = 0.0; var sell = 0.0; var valid = false
        for (pair in pairs) {
            var after: String? = null
            var pages = 0
            var complete = false
            while (pages++ < 100) {
                val page = runCatching { okx.historyTrades(pair, "2", after, 100) }.getOrNull()?.data.orEmpty()
                if (page.isEmpty()) { complete = true; break }
                for (t in page) {
                    val ts = t.ts?.toLongOrNull() ?: continue
                    val q = t.sz?.toDoubleOrNull() ?: continue
                    if (ts >= cutoff && ts < System.currentTimeMillis() && q >= 0.0 && q.isFinite()) {
                        if (t.side.equals("buy", true)) buy += q else if (t.side.equals("sell", true)) sell += q
                        valid = true
                    }
                }
                val oldest = page.minOfOrNull { it.ts?.toLongOrNull() ?: Long.MAX_VALUE } ?: break
                if (oldest <= cutoff) { complete = true; break }
                after = page.lastOrNull()?.tradeId ?: break
            }
            if (!complete) return null
        }
        return if (valid) buy to sell else null
    }

    private suspend fun loadGateNet(coin: String): Pair<Double, Double>? {
        val pairs = getGatePairs().filter {
            it.base.equals(coin, true) && stableQuotes.contains(it.quote?.uppercase(Locale.US)) && !it.tradeStatus.equals("untradable", true)
        }.mapNotNull { it.id }.distinct()
        val now = System.currentTimeMillis()
        val from = now - 86_400_000L
        var buy = 0.0; var sell = 0.0; var valid = false
        for (pair in pairs) {
            var page = 1
            var complete = false
            while (page <= 100) {
                val rows = runCatching { gate.trades(pair, 1000, from / 1000L, now / 1000L, page) }.getOrNull().orEmpty()
                if (rows.isEmpty()) { complete = true; break }
                for (t in rows) {
                    val ts = t.create_time_ms?.toDoubleOrNull()?.let { if (it < 10_000_000_000L) (it * 1000).toLong() else it.toLong() } ?: continue
                    val q = t.amount?.toDoubleOrNull() ?: continue
                    if (ts >= from && ts < now && q >= 0.0 && q.isFinite()) {
                        if (t.side.equals("buy", true)) buy += q else if (t.side.equals("sell", true)) sell += q
                        valid = true
                    }
                }
                if (rows.size < 1000) { complete = true; break }
                page++
            }
            if (!complete) return null
        }
        return if (valid) buy to sell else null
    }

    private suspend fun loadGeminiNet(coin: String): Pair<Double, Double>? {
        val symbols = getGeminiSymbols().filter { s ->
            val u = s.uppercase(Locale.US)
            u.startsWith(coin.uppercase(Locale.US)) && (u.endsWith("USD") || u.endsWith("USDT"))
        }
        if (symbols.isEmpty()) return null
        val since = System.currentTimeMillis() - 86_400_000L
        val now = System.currentTimeMillis()
        var buy = 0.0; var sell = 0.0; var validSymbols = 0
        for (raw in symbols) {
            val pair = raw.lowercase(Locale.US)
            var lastTid: Long? = null
            var pages = 0
            var complete = false
            while (pages++ < 250) {
                val rows = runCatching {
                    gemini.trades(pair, if (lastTid == null) since else null, lastTid, 500)
                }.getOrNull().orEmpty()
                if (rows.isEmpty()) { complete = true; break }
                var saw = false
                for (t in rows) {
                    val ts = t.timestampms ?: continue
                    val q = t.amount?.toDoubleOrNull() ?: continue
                    if (t.broken == true || ts < since || ts >= now || q <= 0.0 || !q.isFinite()) continue
                    when (t.type?.lowercase(Locale.US)) {
                        "buy" -> { buy += q; saw = true }
                        "sell" -> { sell += q; saw = true }
                    }
                }
                if (saw) validSymbols++
                val maxTid = rows.mapNotNull { it.tid }.maxOrNull()
                val newest = rows.maxOfOrNull { it.timestampms ?: Long.MIN_VALUE } ?: Long.MIN_VALUE
                if (rows.size < 500 || newest >= now - 1_000L) { complete = true; break }
                if (maxTid == null || maxTid == lastTid) break
                lastTid = maxTid
            }
            if (!complete) return null
        }
        return if (validSymbols > 0) buy to sell else null
    }

    private suspend fun loadBitfinexNet(coin: String): Pair<Double, Double>? {
        val coinU = coin.uppercase(Locale.US)
        val symbols = getBitfinexPairs().filter { s ->
            val u = s.uppercase(Locale.US)
            u == "T${coinU}USD" || u == "T${coinU}UST"
        }
        if (symbols.isEmpty()) return null
        val now = System.currentTimeMillis()
        val dayStart = now - 86_400_000L
        var buy = 0.0; var sell = 0.0; var valid = false
        for (symbol in symbols) {
            // Adaptive time windows: never treat a capped 10,000-row response as complete.
            val queue = java.util.ArrayDeque<Pair<Long, Long>>()
            queue.add(dayStart to now)
            var complete = true
            while (queue.isNotEmpty()) {
                val (start, end) = queue.removeFirst()
                val rows = runCatching { bitfinex.trades(symbol, 10000, 1, start, end) }.getOrNull() ?: run {
                    complete = false; break
                }
                if (rows.size >= 10000 && end - start > 15L * 60L * 1000L) {
                    val mid = start + (end - start) / 2L
                    queue.addFirst(mid to end)
                    queue.addFirst(start to mid)
                    continue
                }
                for (r in rows) {
                    if (r.size < 3) continue
                    val ts = r[1].asLong
                    val amount = r[2].asDouble
                    if (ts < dayStart || ts >= now || !amount.isFinite() || amount == 0.0) continue
                    if (amount > 0) buy += amount else sell += -amount
                    valid = true
                }
            }
            if (!complete) return null
        }
        return if (valid) buy to sell else null
    }

    private fun tradingViewUrl(coin: String, exchange: String?): String? {
        val ex = when (exchange?.lowercase(Locale.US)) {
            "binance" -> "BINANCE"
            "mexc" -> "MEXC"
            "okx" -> "OKX"
            "bybit" -> "BYBIT"
            "bitget" -> "BITGET"
            "gate.io" -> "GATEIO"
            "gemini" -> "GEMINI"
            "bitfinex" -> "BITFINEX"
            else -> null
        } ?: return null
        return "https://www.tradingview.com/chart/?symbol=${ex}%3A${coin.uppercase(Locale.US)}USDT"
    }
}
