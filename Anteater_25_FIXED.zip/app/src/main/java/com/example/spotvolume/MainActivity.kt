package com.example.spotvolume

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.gson.annotations.SerializedName
import com.google.gson.JsonObject
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query
import java.text.NumberFormat
import java.util.Locale

// v23: clean single-source build. Net Spot Accumulation is the primary signal. Multi-day 3D/5D/7D is secondary.
// Core numerator = Spot taker-buy base-asset quantity. DEX is estimated from on-chain swap trades via GeckoTerminal; derivatives are excluded.

data class CmcStatus(@SerializedName("error_code") val errorCode: Int, @SerializedName("error_message") val errorMessage: String?)
data class CmcResponse(val data: CmcData?, val status: CmcStatus?)
data class CmcData(val marketPairs: List<CmcMarketPair>?)
data class CmcExchange(val name: String?)
data class CmcUsdQuote(@SerializedName("volume_24h") val volume24h: Double?)
data class CmcQuote(val USD: CmcUsdQuote?)
data class CmcMarketPair(val exchange: CmcExchange?, @SerializedName("market_id") val marketId: Long?, @SerializedName("market_pair") val marketPair: String?, val category: String?, val quote: CmcQuote?)

data class CmcSupplyResponse(val data: List<CmcSupplyAsset>?, val status: CmcStatus?)
data class CmcSupplyAsset(val symbol: String?, @SerializedName("circulating_supply") val circulatingSupply: Double?, @SerializedName("total_supply") val totalSupply: Double?)

interface CmcApi {
    @GET("v2/cryptocurrency/info") suspend fun info(@Query("symbol") symbol: String, @Header("X-CMC_PRO_API_KEY") key: String): CmcSupplyResponse
    @GET("public-api/v3/cryptocurrency/quotes/latest") suspend fun publicQuotes(@Query("symbol") symbol: String): CmcPublicQuotesResponse
}
data class CmcPublicQuotesResponse(val data: Map<String, CmcPublicAsset>?, val status: CmcStatus?)
data class CmcPublicAsset(val symbol: String?, @SerializedName("circulating_supply") val circulatingSupply: Double?, @SerializedName("total_supply") val totalSupply: Double?)

// CoinPaprika public fallback for circulating supply. No API key required for basic endpoints.
data class PaprikaSearchResponse(val currencies: List<PaprikaCoin>?)
data class PaprikaCoin(val id: String?, val symbol: String?, val name: String?)
data class PaprikaSupplyResponse(val id: String?, val symbol: String?, @SerializedName("circulating_supply") val circulatingSupply: Double?, @SerializedName("total_supply") val totalSupply: Double?)
data class PaprikaTicker(val id: String?, val symbol: String?, @SerializedName("circulating_supply") val circulatingSupply: Double?)
interface PaprikaApi {
    @GET("v1/search") suspend fun search(@Query("q") query: String, @Query("c") category: String = "currencies"): PaprikaSearchResponse
    @GET("v1/tickers") suspend fun tickers(@Query("quotes") quotes: String = "USD", @Query("limit") limit: Int = 0): List<PaprikaTicker>
    @GET("v1/coins/{id}") suspend fun coin(@retrofit2.http.Path("id") id: String): PaprikaSupplyResponse
}

// CoinGecko public fallback for circulating supply.
data class GeckoSearchResponse(val coins: List<GeckoCoin>?)
data class GeckoCoin(val id: String?, val symbol: String?, val name: String?, @SerializedName("market_cap_rank") val marketCapRank: Int?)
data class GeckoMarketData(@SerializedName("circulating_supply") val circulatingSupply: Double?, @SerializedName("total_supply") val totalSupply: Double?)
data class GeckoCoinResponse(val id: String?, val symbol: String?, val marketData: GeckoMarketData?)
interface CoinGeckoApi {
    @GET("api/v3/search") suspend fun search(@Query("query") query: String): GeckoSearchResponse
    @GET("api/v3/coins/{id}") suspend fun coin(@retrofit2.http.Path("id") id: String, @Query("localization") localization: Boolean = false, @Query("tickers") tickers: Boolean = false, @Query("market_data") marketData: Boolean = true, @Query("community_data") communityData: Boolean = false, @Query("developer_data") developerData: Boolean = false, @Query("sparkline") sparkline: Boolean = false): GeckoCoinResponse
}

// Binance Spot
interface BinanceApi {
    @GET("api/v3/exchangeInfo") suspend fun exchangeInfo(): BinanceExchangeInfo
    @GET("api/v3/klines") suspend fun klines(@Query("symbol") symbol: String, @Query("interval") interval: String = "1d", @Query("limit") limit: Int = 8): List<List<com.google.gson.JsonElement>>
}
data class BinanceExchangeInfo(val symbols: List<BinanceSymbol>?)
data class BinanceSymbol(val symbol: String?, val status: String?, val baseAsset: String?, val quoteAsset: String?)

// MEXC Spot. Its public Spot kline schema follows the same Binance-style 12-field layout,
// including takerBuyBaseVolume at index 9. The adapter is intentionally limited to Spot symbols.
interface MexcApi {
    @GET("api/v3/exchangeInfo") suspend fun exchangeInfo(): MexcExchangeInfo
    @GET("api/v3/aggTrades") suspend fun aggTrades(
        @Query("symbol") symbol: String,
        @Query("startTime") startTime: Long? = null,
        @Query("endTime") endTime: Long? = null,
        @Query("fromId") fromId: Long? = null,
        @Query("limit") limit: Int = 1000
    ): List<List<com.google.gson.JsonElement>>
}
data class MexcExchangeInfo(val symbols: List<MexcSymbol>?)
data class MexcSymbol(val symbol: String?, val status: String?, val baseAsset: String?, val quoteAsset: String?)

// OKX public Spot market history. The API explicitly labels side as the taker side.
interface OkxApi {
    @GET("api/v5/public/instruments") suspend fun instruments(@Query("instType") instType: String = "SPOT"): OkxInstrumentsResponse
    @GET("api/v5/market/history-trades") suspend fun historyTrades(
        @Query("instId") instId: String,
        @Query("type") type: String = "2",
        @Query("after") after: String? = null,
        @Query("limit") limit: Int = 100
    ): OkxTradesResponse
}
data class OkxInstrumentsResponse(val code: String?, val data: List<OkxInstrument>?)
data class OkxInstrument(val instId: String?, val baseCcy: String?, val quoteCcy: String?, val state: String?)
data class OkxTradesResponse(val code: String?, val data: List<OkxTrade>?)
data class OkxTrade(val instId: String?, val side: String?, val sz: String?, val tradeId: String?, val ts: String?)

data class SourceResult(val name: String, val values: DoubleArray, val pairs: Int)
data class AutoScanRow(
    val symbol: String,
    val buy: Double,
    val sell: Double,
    val net: Double,
    val supply: Double,
    val ratioPct: Double,
    val exchanges: String,
    val tradingViewUrl: String?
)

// Bybit Spot public trades: side is the taker side.
interface BybitApi {
    @GET("v5/market/recent-trade") suspend fun recentTrade(@Query("category") category: String = "spot", @Query("symbol") symbol: String, @Query("limit") limit: Int = 60): BybitResponse
}
data class BybitResponse(val retCode: Int?, val result: BybitResult?)
data class BybitResult(val list: List<BybitTrade>?)
data class BybitTrade(val price: String?, val size: String?, val side: String?, val time: String?)

interface BitgetApi {
    @GET("api/v3/market/fills") suspend fun fills(@Query("category") category: String = "SPOT", @Query("symbol") symbol: String, @Query("limit") limit: Int = 100): BitgetResponse
    @GET("api/v3/market/instruments") suspend fun instruments(@Query("category") category: String = "SPOT"): BitgetInstrumentsResponse
}
data class BitgetResponse(val code: String?, val data: List<BitgetFill>?)
data class BitgetFill(val size: String?, val side: String?, val ts: String?)
data class BitgetInstrumentsResponse(val code: String?, val data: List<BitgetInstrument>?)
data class BitgetInstrument(val symbol: String?, val baseCoin: String?, val quoteCoin: String?, val status: String?)

interface GateApi {
    @GET("api/v4/spot/currency_pairs") suspend fun currencyPairs(): List<GatePair>
    @GET("api/v4/spot/trades") suspend fun trades(@Query("currency_pair") pair: String, @Query("limit") limit: Int = 1000): List<GateTrade>
}
data class GatePair(val id: String?, val base: String?, val quote: String?, val tradeStatus: String?)
data class GateTrade(val id: String?, val create_time_ms: String?, val side: String?, val amount: String?)

interface CoinExApi {
    @GET("v2/spot/market/ticker") suspend fun ticker(@Query("market") market: String? = null): CoinExTickerResponse
    @GET("v2/spot/market") suspend fun marketList(): CoinExMarketsResponse
}
data class CoinExTickerResponse(val code: Int?, val data: List<CoinExTicker>?)
data class CoinExTicker(val market: String?, val volume_buy: String?, val period: Int?)
data class CoinExMarketsResponse(val code: Int?, val data: List<CoinExMarket>?)
data class CoinExMarket(val market: String?, val base_ccy: String?, val quote_ccy: String?)

// GeckoTerminal public on-chain DEX data. Public API is unauthenticated and currently rate-limited.
interface GeckoApi {
    @GET("api/v2/search/pools") suspend fun searchPools(@Query("query") query: String, @Query("page") page: Int = 1): GeckoPoolSearchResponse
    @GET("api/v2/networks/{network}/pools/{pool}/trades") suspend fun trades(@retrofit2.http.Path("network") network: String, @retrofit2.http.Path("pool") pool: String, @Query("page") page: Int = 1): GeckoTradesResponse
}
data class GeckoPoolSearchResponse(val data: List<GeckoData>?)
data class GeckoTradesResponse(val data: List<GeckoData>?)
data class GeckoData(val id: String?, val type: String?, val attributes: JsonObject?)


private val stableQuotes = setOf("USDT", "USDC", "FDUSD", "USD")
private fun compact(value: Double): String = when {
    value >= 1e12 -> "${(value / 1e12).format1()}T"
    value >= 1e9 -> "${(value / 1e9).format1()}B"
    value >= 1e6 -> "${(value / 1e6).format1()}M"
    value >= 1e3 -> "${(value / 1e3).format1()}K"
    else -> value.format1()
}
private fun Double.format1(): String = String.format(Locale.US, "%.1f", this)

class SpotViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.applicationContext.getSharedPreferences("spot_volume", 0)
    var symbol by mutableStateOf("BTC")
    var apiKey by mutableStateOf("")
    var loading by mutableStateOf(false)
    var statusText by mutableStateOf("")
    var error by mutableStateOf<String?>(null)
    var circulatingSupply by mutableStateOf<Double?>(null)
    var totalSupply by mutableStateOf<Double?>(null)
    var dailyBuy by mutableStateOf<Double?>(null)
    var dailyCexBuy by mutableStateOf<Double?>(null)
    var dailyDexBuy by mutableStateOf<Double?>(null)
    var dailySell by mutableStateOf<Double?>(null)
    var dailyNet by mutableStateOf<Double?>(null)
    var netRatioPct by mutableStateOf<Double?>(null)
    var dailySourceCount by mutableStateOf(0)
    var buy3d by mutableStateOf<Double?>(null)
    var buy5d by mutableStateOf<Double?>(null)
    var buy7d by mutableStateOf<Double?>(null)
    var sourceCount by mutableStateOf(0)
    var sourceNote by mutableStateOf("")
    var anomalyMultiple by mutableStateOf<Double?>(null)
    var anomalyDeltaPct by mutableStateOf<Double?>(null)
    var autoScanning by mutableStateOf(false)
    var autoScanStatus by mutableStateOf("")
    var autoScanFound by mutableStateOf(0)
    var autoScanResults by mutableStateOf<List<AutoScanRow>>(emptyList())
    var scanIntervalMinutes by mutableStateOf(prefs.getInt("scan_interval_minutes", 5))
    var continuousScanEnabled by mutableStateOf(prefs.getBoolean("continuous_scan_enabled", true))

    private val cmc = Retrofit.Builder().baseUrl("https://pro-api.coinmarketcap.com/").addConverterFactory(GsonConverterFactory.create()).build().create(CmcApi::class.java)
    private val paprika = Retrofit.Builder().baseUrl("https://api.coinpaprika.com/").addConverterFactory(GsonConverterFactory.create()).build().create(PaprikaApi::class.java)
    private val coinGecko = Retrofit.Builder().baseUrl("https://api.coingecko.com/").addConverterFactory(GsonConverterFactory.create()).build().create(CoinGeckoApi::class.java)
    private val binance = Retrofit.Builder().baseUrl("https://data-api.binance.vision/").addConverterFactory(GsonConverterFactory.create()).build().create(BinanceApi::class.java)
    private val mexc = Retrofit.Builder().baseUrl("https://api.mexc.com/").addConverterFactory(GsonConverterFactory.create()).build().create(MexcApi::class.java)
    private val okx = Retrofit.Builder().baseUrl("https://www.okx.com/").addConverterFactory(GsonConverterFactory.create()).build().create(OkxApi::class.java)
    private val bybit = Retrofit.Builder().baseUrl("https://api.bybit.com/").addConverterFactory(GsonConverterFactory.create()).build().create(BybitApi::class.java)
    private val bitget = Retrofit.Builder().baseUrl("https://api.bitget.com/").addConverterFactory(GsonConverterFactory.create()).build().create(BitgetApi::class.java)
    private val gate = Retrofit.Builder().baseUrl("https://api.gateio.ws/").addConverterFactory(GsonConverterFactory.create()).build().create(GateApi::class.java)
    private val coinex = Retrofit.Builder().baseUrl("https://api.coinex.com/").addConverterFactory(GsonConverterFactory.create()).build().create(CoinExApi::class.java)
    private val gecko = Retrofit.Builder().baseUrl("https://api.geckoterminal.com/").addConverterFactory(GsonConverterFactory.create()).build().create(GeckoApi::class.java)

    init { apiKey = prefs.getString("api_key", "") ?: "" }
    fun saveKey() { prefs.edit().putString("api_key", apiKey.trim()).apply() }

    fun load() {
        saveKey()
        val coin = symbol.trim().uppercase(Locale.US)
        if (coin.isBlank()) { error = "Enter a crypto symbol."; return }
        viewModelScope.launch {
            loading = true; error = null; statusText = "Loading supply and verified CEX Spot buy data…"
            dailyBuy = null; dailyCexBuy = null; dailyDexBuy = null; dailySell = null; dailyNet = null; netRatioPct = null; dailySourceCount = 0; buy3d = null; buy5d = null; buy7d = null; circulatingSupply = null; totalSupply = null; sourceCount = 0; sourceNote = ""; anomalyMultiple = null; anomalyDeltaPct = null
            try {
                val supplyJob = async { loadSupply(coin) }
                val sourceJobs = listOf(
                    async { runCatching { loadBinance(coin) }.getOrNull() },
                    async { runCatching { loadMexc(coin) }.getOrNull() },
                    async { runCatching { loadOkx(coin) }.getOrNull() },
                    async { runCatching { loadBybit(coin) }.getOrNull() },
                    async { runCatching { loadBitget(coin) }.getOrNull() },
                    async { runCatching { loadGate(coin) }.getOrNull() },
                    async { runCatching { loadCoinEx(coin) }.getOrNull() }
                )
                val dexJob = async { runCatching { loadDexToday(coin) }.getOrNull() }
                val supply = supplyJob.await()
                val results = sourceJobs.awaitAll().filterNotNull()
                val dex = dexJob.await()
                circulatingSupply = supply.first
                totalSupply = supply.second
                val sums = doubleArrayOf(0.0, 0.0, 0.0)
                var count = 0
                results.forEach { r -> for (i in 0..2) sums[i] += r.values[i]; if (r.pairs > 0) count++ }
                buy3d = if (count > 0) sums[0] else null
                buy5d = if (count > 0) sums[1] else null
                buy7d = if (count > 0) sums[2] else null
                dailyCexBuy = results.sumOf { it.values[3].takeIf { v -> v.isFinite() && v >= 0 } ?: 0.0 }.takeIf { it > 0 }
                dailyDexBuy = dex?.values?.getOrNull(3)?.takeIf { it.isFinite() && it >= 0 }
                dailyBuy = listOfNotNull(dailyCexBuy, dailyDexBuy).takeIf { it.isNotEmpty() }?.sum()
                sourceCount = count
                dailySourceCount = count + if (dailyDexBuy != null) 1 else 0
                sourceNote = "CEX: ${results.joinToString { it.name }}${if (dailyDexBuy != null) "; DEX: GeckoTerminal top pools" else "; DEX: no verified data returned"}."
                val net = runCatching { scanNetAcrossSources(coin, supply.first ?: 0.0) }.getOrNull()
                if (net != null) {
                    dailySell = net.sell
                    dailyNet = net.net
                    netRatioPct = net.ratioPct
                }
                if (dailyBuy != null && supply.first != null && supply.first!! > 0.0 && buy7d != null && buy7d!! > dailyBuy!! && buy5d != null && buy5d!! > dailyBuy!! && buy3d != null && buy3d!! > dailyBuy!!) {
                    val priorMeans = listOf(
                        (buy3d!! - dailyBuy!!) / 2.0,
                        (buy5d!! - dailyBuy!!) / 4.0,
                        (buy7d!! - dailyBuy!!) / 6.0
                    ).filter { it > 0 && it.isFinite() }
                    if (priorMeans.isNotEmpty()) {
                        val sorted = priorMeans.sorted()
                        val priorAvg = sorted[sorted.size / 2]
                        anomalyMultiple = dailyBuy!! / priorAvg
                        anomalyDeltaPct = (anomalyMultiple!! - 1.0) * 100.0
                    }
                }
                statusText = "Daily Buy is primary. CEX + DEX Spot only; multi-day is secondary."
            } catch (e: Exception) { error = e.message ?: "Network error." }
            finally { loading = false }
        }
    }

    fun saveScanSettings(minutes: Int, enabled: Boolean) {
        scanIntervalMinutes = minutes.coerceIn(1, 60)
        continuousScanEnabled = enabled
        prefs.edit().putInt("scan_interval_minutes", scanIntervalMinutes).putBoolean("continuous_scan_enabled", continuousScanEnabled).apply()
        val ctx=getApplication<Application>().applicationContext
        if(enabled){ if(Build.VERSION.SDK_INT>=26) ctx.startForegroundService(Intent(ctx,AnteaterScanService::class.java)) else ctx.startService(Intent(ctx,AnteaterScanService::class.java)) }
        else ctx.stopService(Intent(ctx,AnteaterScanService::class.java))
    }

    fun scanNow() {
        autoScan()
    }

    fun autoScan(): Job? {
        if (loading || autoScanning) return null
        return viewModelScope.launch {
            autoScanning = true
            autoScanFound = 0
            autoScanResults = emptyList()
            autoScanStatus = "Building multi-exchange Spot universe…"
            try {
                val info = binance.exchangeInfo()
                val quotePriority = listOf("USDT", "USDC", "FDUSD", "USD")
                val pairsByBase = info.symbols.orEmpty()
                    .filter { it.status.equals("TRADING", true) && quotePriority.contains(it.quoteAsset?.uppercase(Locale.US)) }
                    .groupBy { it.baseAsset?.uppercase(Locale.US).orEmpty() }
                    .filterKeys { it.isNotBlank() }
                val pairs = pairsByBase.mapNotNull { (base, symbols) ->
                    val chosen = quotePriority.firstNotNullOfOrNull { q -> symbols.firstOrNull { it.quoteAsset.equals(q, true) }?.symbol }
                    if (chosen != null) base to chosen else null
                }
                autoScanStatus = "Loading circulating supply…"
                val supplyMap = runCatching {
                    paprika.tickers("USD", 0).mapNotNull { t ->
                        val sym = t.symbol?.uppercase(Locale.US); val sup = t.circulatingSupply
                        if (sym != null && sup != null && sup > 0.0) sym to sup else null
                    }.toMap()
                }.getOrDefault(emptyMap())

                // Fast discovery: Binance daily taker-buy vs the rest of Spot volume.
                // Only candidates with positive net flow are promoted to full CEX+DEX verification.
                val candidates = mutableListOf<Triple<String, Double, Double>>()
                var checked = 0
                for (chunk in pairs.chunked(12)) {
                    val jobs = chunk.map { (base, pair) -> async {
                        runCatching {
                            val row = binance.klines(pair, "1d", 1).lastOrNull()
                            val total = row?.getOrNull(5)?.asString?.toDoubleOrNull()
                            val buy = row?.getOrNull(9)?.asString?.toDoubleOrNull()
                            if (total != null && buy != null && total >= buy && buy >= 0.0) Triple(base, buy, total - buy) else null
                        }.getOrNull()
                    }}
                    jobs.awaitAll().filterNotNullTo(mutableListOf()).forEach { candidates += it }
                    checked += chunk.size
                    autoScanStatus = "Discovering Spot net flow… $checked / ${pairs.size}"
                    delay(50)
                }

                // Verify candidates against every supported CEX/DEX adapter. The adapter itself
                // returns no data when a source cannot reliably expose Spot buy/sell direction.
                val prelim = candidates.mapNotNull { (base, binBuy, binSell) ->
                    val supply = supplyMap[base] ?: return@mapNotNull null
                    val binNet = binBuy - binSell
                    if (binNet <= 0.0) return@mapNotNull null
                    base to Pair(supply, binNet)
                }.sortedByDescending { it.second.second / it.second.first }
                    .take(80)

                val verified = mutableListOf<AutoScanRow>()
                var v = 0
                for ((base, infoPair) in prelim) {
                    autoScanStatus = "Verifying $base across supported CEX + DEX… ${v + 1} / ${prelim.size}"
                    val result = runCatching { scanNetAcrossSources(base, infoPair.first) }.getOrNull()
                    if (result != null && result.net > 0.0) {
                        verified += result
                        autoScanFound = verified.size
                    }
                    v++
                }
                autoScanResults = verified.sortedByDescending { it.ratioPct }
                autoScanFound = autoScanResults.size
                autoScanStatus = "Finished. ${autoScanResults.size} verified net-accumulation signals."
                notifySignals(autoScanResults)
            } catch (e: Exception) {
                autoScanStatus = "Auto scan failed: ${e.message ?: "network error"}"
            } finally { autoScanning = false }
        }
    }

    private suspend fun scanNetAcrossSources(coin: String, supply: Double): AutoScanRow? {
        var buy = 0.0; var sell = 0.0
        val names = mutableListOf<String>()
        // Binance is the only source here with a complete daily buy/sell split from public klines.
        val b = runCatching { loadBinanceNet(coin) }.getOrNull()
        if (b != null) { buy += b.first; sell += b.second; names += "Binance" }
        // Other adapters expose directional trades; only count sources that returned usable data.
        val m = runCatching { loadMexcNet(coin) }.getOrNull()
        if (m != null) { buy += m.first; sell += m.second; names += "MEXC" }
        val o = runCatching { loadOkxNet(coin) }.getOrNull()
        if (o != null) { buy += o.first; sell += o.second; names += "OKX" }
        val by = runCatching { loadBybitNet(coin) }.getOrNull()
        if (by != null) { buy += by.first; sell += by.second; names += "Bybit" }
        val bg = runCatching { loadBitgetNet(coin) }.getOrNull()
        if (bg != null) { buy += bg.first; sell += bg.second; names += "Bitget" }
        val gt = runCatching { loadGateNet(coin) }.getOrNull()
        if (gt != null) { buy += gt.first; sell += gt.second; names += "Gate.io" }
        val ce = runCatching { loadCoinExNet(coin) }.getOrNull()
        if (ce != null) { buy += ce.first; sell += ce.second; names += "CoinEx" }
        val dx = runCatching { loadDexNet(coin) }.getOrNull()
        if (dx != null) { buy += dx.first; sell += dx.second; names += "DEX" }
        val net = buy - sell
        if (net <= 0.0 || names.isEmpty()) return null
        val ratio = net / supply * 100.0
        val tv = tradingViewUrl(coin, names.firstOrNull())
        return AutoScanRow(coin, buy, sell, net, supply, ratio, names.joinToString(", "), tv)
    }

    private suspend fun loadBinanceNet(coin: String): Pair<Double,Double>? {
        val info = binance.exchangeInfo(); val pairs = info.symbols.orEmpty().filter { it.status == "TRADING" && it.baseAsset.equals(coin,true) && stableQuotes.contains(it.quoteAsset?.uppercase(Locale.US)) }.mapNotNull { it.symbol }.distinct()
        var buy=0.0; var sell=0.0; var valid=false
        for(p in pairs){ val r=runCatching{binance.klines(p,"1d",1).lastOrNull()}.getOrNull() ?: continue; val total=r.getOrNull(5)?.asString?.toDoubleOrNull(); val b=r.getOrNull(9)?.asString?.toDoubleOrNull(); if(total!=null&&b!=null&&total>=b){buy+=b;sell+=total-b;valid=true} }
        return if(valid) buy to sell else null
    }
    private suspend fun loadMexcNet(coin:String):Pair<Double,Double>? { return loadMexcDirectional(coin) }
    private suspend fun loadMexcDirectional(coin:String):Pair<Double,Double>? {
        val info=mexc.exchangeInfo(); val pairs=info.symbols.orEmpty().filter{(it.status.equals("ENABLED",true)||it.status.equals("TRADING",true))&&it.baseAsset.equals(coin,true)&&stableQuotes.contains(it.quoteAsset?.uppercase(Locale.US))}.mapNotNull{it.symbol}.distinct(); var buy=0.0;var sell=0.0;var valid=false;val since=System.currentTimeMillis()-86400000L
        for(p in pairs){val rows=runCatching{mexc.aggTrades(p,startTime=since,endTime=System.currentTimeMillis(),limit=1000)}.getOrNull().orEmpty();for(r in rows){if(r.size<7)continue;val q=r[4].asString.toDoubleOrNull()?:continue;if(r[5].asLong<since)continue;if(!r[6].asBoolean)buy+=q else sell+=q;valid=true}}
        return if(valid)buy to sell else null
    }
    private suspend fun loadOkxNet(coin:String):Pair<Double,Double>? { val info=okx.instruments("SPOT");var b=0.0;var s=0.0;var v=false;for(p in info.data.orEmpty().filter{it.state.equals("live",true)&&it.baseCcy.equals(coin,true)&&stableQuotes.contains(it.quoteCcy?.uppercase(Locale.US))}.mapNotNull{it.instId}.distinct()){val rows=runCatching{okx.historyTrades(p,"2",null,100)}.getOrNull()?.data.orEmpty();for(t in rows){val q=t.sz?.toDoubleOrNull()?:continue;if(t.side.equals("buy",true))b+=q else if(t.side.equals("sell",true))s+=q;v=true}};return if(v)b to s else null }
    private suspend fun loadBybitNet(coin:String):Pair<Double,Double>? {var b=0.0;var s=0.0;var v=false;for(q in listOf("USDT","USDC")){val rows=runCatching{bybit.recentTrade(symbol="${coin.uppercase(Locale.US)}$q",limit=1000)}.getOrNull()?.result?.list.orEmpty();for(t in rows){val x=t.size?.toDoubleOrNull()?:continue;if(t.side.equals("Buy",true))b+=x else if(t.side.equals("Sell",true))s+=x;v=true}};return if(v)b to s else null}
    private suspend fun loadBitgetNet(coin:String):Pair<Double,Double>? {val info=bitget.instruments("SPOT");var b=0.0;var s=0.0;var v=false;for(p in info.data.orEmpty().filter{it.baseCoin.equals(coin,true)&&stableQuotes.contains(it.quoteCoin?.uppercase(Locale.US))}.mapNotNull{it.symbol}.distinct()){for(f in runCatching{bitget.fills("SPOT",p,1000)}.getOrNull()?.data.orEmpty()){val x=f.size?.toDoubleOrNull()?:continue;if(f.side.equals("buy",true))b+=x else if(f.side.equals("sell",true))s+=x;v=true}};return if(v)b to s else null}
    private suspend fun loadGateNet(coin:String):Pair<Double,Double>? {var b=0.0;var s=0.0;var v=false;for(p in gate.currencyPairs().filter{it.base.equals(coin,true)&&stableQuotes.contains(it.quote?.uppercase(Locale.US))}.mapNotNull{it.id}.distinct()){for(t in runCatching{gate.trades(p,1000)}.getOrNull().orEmpty()){val x=t.amount?.toDoubleOrNull()?:continue;if(t.side.equals("buy",true))b+=x else if(t.side.equals("sell",true))s+=x;v=true}};return if(v)b to s else null}
    private suspend fun loadCoinExNet(coin:String):Pair<Double,Double>? {var b=0.0;var s=0.0;var v=false;for(m in coinex.marketList().data.orEmpty().filter{it.base_ccy.equals(coin,true)&&stableQuotes.contains(it.quote_ccy?.uppercase(Locale.US))}.mapNotNull{it.market}.distinct()){val r=runCatching{coinex.ticker(m)}.getOrNull()?.data?.firstOrNull()?:continue;val x=r.volume_buy?.toDoubleOrNull()?:continue;b+=x;v=true};return if(v)b to s else null}
    private suspend fun loadDexNet(coin:String):Pair<Double,Double>? { val found=runCatching{gecko.searchPools(coin.uppercase(Locale.US),1)}.getOrNull()?.data.orEmpty().take(20);if(found.isEmpty())return null;var b=0.0;var s=0.0;var v=false;val since=System.currentTimeMillis()-86400000L;for(d in found){val parts=d.id?.split("_")?:continue;if(parts.size<2)continue;for(t in runCatching{gecko.trades(parts[0],parts[1],1)}.getOrNull()?.data.orEmpty()){val a=t.attributes?:continue;val ts=runCatching{java.time.Instant.parse(a.get("block_timestamp")?.asString).toEpochMilli()}.getOrNull()?:continue;if(ts<since)continue;val k=a.get("kind")?.asString?.lowercase(Locale.US);val x=a.get("to_token_amount")?.asString?.toDoubleOrNull()?:a.get("from_token_amount")?.asString?.toDoubleOrNull()?:continue;if(k=="buy")b+=x else if(k=="sell")s+=x;v=true}};return if(v)b to s else null }

    private fun tradingViewUrl(coin: String, exchange: String?): String? {
        val ex = when(exchange?.lowercase(Locale.US)) {
            "binance" -> "BINANCE"
            "mexc" -> "MEXC"
            "okx" -> "OKX"
            "bybit" -> "BYBIT"
            "bitget" -> "BITGET"
            "gate.io" -> "GATEIO"
            "coinex" -> "COINEX"
            else -> null
        } ?: return null
        return "https://www.tradingview.com/chart/?symbol=${ex}%3A${coin.uppercase(Locale.US)}USDT"
    }

    private fun notifySignals(rows: List<AutoScanRow>) {
        val hit = rows.firstOrNull { it.ratioPct > 0.0 } ?: return
        val nm = getApplication<Application>().applicationContext
        val mgr = nm.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId="anteater_signals"
        if(Build.VERSION.SDK_INT>=26) mgr.createNotificationChannel(NotificationChannel(channelId,"Anteater Signals",NotificationManager.IMPORTANCE_HIGH))
        val text="${hit.symbol}: +${compact(hit.net)} net • ${hit.ratioPct.format1()}% supply • ${hit.exchanges}"
        val intent=Intent(nm,MainActivity::class.java).apply{flags=Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP}
        val pi=android.app.PendingIntent.getActivity(nm,hit.symbol.hashCode(),intent,android.app.PendingIntent.FLAG_UPDATE_CURRENT or if(Build.VERSION.SDK_INT>=23) android.app.PendingIntent.FLAG_IMMUTABLE else 0)
        val builder=NotificationCompat.Builder(nm,channelId).setSmallIcon(com.example.spotvolume.R.mipmap.ic_launcher).setContentTitle("Anteater • Significant accumulation").setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText("Buy: ${compact(hit.buy)} ${hit.symbol}\nSell: ${compact(hit.sell)} ${hit.symbol}\nNet accumulation: ${compact(hit.net)} ${hit.symbol}\nNet / circulating supply: ${hit.ratioPct.format1()}%\nSources: ${hit.exchanges}\nTradingView: ${hit.tradingViewUrl ?: "not available"}" )).setContentIntent(pi).setAutoCancel(true)
        hit.tradingViewUrl?.let { url ->
            val tvIntent=Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
            val tvPi=android.app.PendingIntent.getActivity(nm, (hit.symbol+"tv").hashCode(), tvIntent, android.app.PendingIntent.FLAG_UPDATE_CURRENT or if(Build.VERSION.SDK_INT>=23) android.app.PendingIntent.FLAG_IMMUTABLE else 0)
            builder.addAction(NotificationCompat.Action.Builder(0,"TradingView",tvPi).build())
        }
        val n=builder.build()
        if(Build.VERSION.SDK_INT<33 || NotificationManagerCompat.from(nm).areNotificationsEnabled()) mgr.notify(1001,n)
    }

    private suspend fun loadSupply(coin: String): Pair<Double?, Double?> {
        // 1) Authenticated CMC when a user key is supplied.
        if (apiKey.isNotBlank()) {
            val cmcResult = runCatching { cmc.info(coin, apiKey.trim()) }.getOrNull()
            val asset = cmcResult?.data?.firstOrNull { it.symbol.equals(coin, ignoreCase = true) }
            if (cmcResult?.status?.errorCode == 0 && asset?.circulatingSupply != null && asset.circulatingSupply > 0.0) {
                return asset.circulatingSupply to asset.totalSupply
            }
        }

        // 2) CoinPaprika exact-symbol fallback.
        val paprikaSupply = runCatching {
            val search = paprika.search(coin)
            val match = search.currencies.orEmpty().firstOrNull { it.symbol.equals(coin, ignoreCase = true) }
            val id = match?.id ?: return@runCatching null
            val p = paprika.coin(id)
            val circ = p.circulatingSupply
            if (circ != null && circ > 0.0) circ to p.totalSupply else null
        }.getOrNull()
        if (paprikaSupply != null) return paprikaSupply

        // 3) CoinGecko public fallback. This avoids showing a blank denominator
        // when CoinPaprika is rate-limited or temporarily unavailable.
        val geckoSupply = runCatching {
            val search = coinGecko.search(coin)
            val exact = search.coins.orEmpty()
                .filter { it.symbol.equals(coin, ignoreCase = true) }
                .sortedWith(compareBy<GeckoCoin> { it.marketCapRank ?: Int.MAX_VALUE }.thenBy { it.id ?: "" })
                .firstOrNull()
            val id = exact?.id ?: return@runCatching null
            val g = coinGecko.coin(id)
            val circ = g.marketData?.circulatingSupply
            if (circ != null && circ > 0.0) circ to g.marketData?.totalSupply else null
        }.getOrNull()
        if (geckoSupply != null) return geckoSupply

        throw IllegalStateException("Circulating supply is unavailable for $coin from the verified public supply sources.")
    }

    private fun aggregate(rowsByPair: List<List<List<com.google.gson.JsonElement>>>): SourceResult? {
        val totals = doubleArrayOf(0.0, 0.0, 0.0, 0.0)
        var pairs = 0
        val now = System.currentTimeMillis()
        rowsByPair.forEach { rows ->
            val completed = rows.filter { row -> row.size > 9 && row[6].asLong < now }.takeLast(7)
            if (completed.isNotEmpty()) {
                pairs++
                val vals = completed.mapNotNull { it[9].asString.toDoubleOrNull()?.takeIf { x -> x.isFinite() && x >= 0.0 } }
                if (vals.isNotEmpty()) {
                    totals[3] += vals.last()
                    totals[0] += vals.takeLast(3).sum()
                    totals[1] += vals.takeLast(5).sum()
                    totals[2] += vals.takeLast(7).sum()
                }
            }
        }
        return if (pairs > 0) SourceResult("", totals, pairs) else null
    }

    private suspend fun loadBinance(coin: String): SourceResult? {
        val info = binance.exchangeInfo()
        val pairs = info.symbols.orEmpty().filter { it.status == "TRADING" && it.baseAsset.equals(coin, true) && stableQuotes.contains(it.quoteAsset?.uppercase(Locale.US)) }.mapNotNull { it.symbol }.distinct()
        val rows = pairs.map { p -> runCatching { binance.klines(p) }.getOrDefault(emptyList()) }
        return aggregate(rows)?.copy(name = "Binance")
    }

    private suspend fun loadMexc(coin: String): SourceResult? {
        val info = mexc.exchangeInfo()
        val pairs = info.symbols.orEmpty()
            .filter { it.status.equals("ENABLED", true) || it.status.equals("TRADING", true) }
            .filter { it.baseAsset.equals(coin, true) && stableQuotes.contains(it.quoteAsset?.uppercase(Locale.US)) }
            .mapNotNull { it.symbol }.distinct()

        // MEXC v3 klines do NOT expose taker-buy volume. Use aggregate trades instead:
        // m=true means buyer was maker, therefore !m is an aggressive/taker buy.
        val sevenDaysAgo = System.currentTimeMillis() - 7L * 24L * 60L * 60L * 1000L
        val totals = doubleArrayOf(0.0, 0.0, 0.0, 0.0)
        var validPairs = 0
        for (pair in pairs) {
            var cursor = sevenDaysAgo
            var pairHadData = false
            var guard = 0
            while (cursor < System.currentTimeMillis() && guard++ < 20000) {
                val end = minOf(System.currentTimeMillis(), cursor + 6L * 60L * 60L * 1000L)
                var fromId: Long? = null
                var pageGuard = 0
                var finishedWindow = false
                while (!finishedWindow && pageGuard++ < 20000) {
                    val rows = runCatching { mexc.aggTrades(pair, if (fromId == null) cursor else null, if (fromId == null) end else null, fromId, 1000) }.getOrDefault(emptyList())
                    if (rows.isEmpty()) { finishedWindow = true; break }
                    rows.forEach { r ->
                        val ts = r[5].asLong
                        val qty = r[4].asString.toDoubleOrNull() ?: return@forEach
                        val isTakerBuy = !r[6].asBoolean
                        if (isTakerBuy && ts >= sevenDaysAgo && ts < System.currentTimeMillis() && qty.isFinite() && qty >= 0) {
                            val ageDays = (System.currentTimeMillis() - ts) / 86400000.0
                            if (ageDays < 1.0) totals[3] += qty
                            if (ageDays <= 3.0) totals[0] += qty
                            if (ageDays <= 5.0) totals[1] += qty
                            totals[2] += qty
                            pairHadData = true
                        }
                    }
                    val lastTs = rows.maxOfOrNull { it[5].asLong } ?: end
                    val lastId = rows.maxOfOrNull { it[0].asLong }
                    if (lastTs >= end || rows.size < 1000) {
                        finishedWindow = true
                    } else {
                        fromId = (lastId ?: Long.MAX_VALUE) + 1L
                    }
                }
                cursor = end + 1
            }
            if (pairHadData) validPairs++
        }
        return if (validPairs > 0) SourceResult("MEXC", totals, validPairs) else null
    }

    private suspend fun loadOkx(coin: String): SourceResult? {
        val info = okx.instruments("SPOT")
        val pairs = info.data.orEmpty()
            .filter { it.state.equals("live", true) && it.baseCcy.equals(coin, true) && stableQuotes.contains(it.quoteCcy?.uppercase(Locale.US)) }
            .mapNotNull { it.instId }.distinct()

        val cutoff = System.currentTimeMillis() - 7L * 24L * 60L * 60L * 1000L
        val totals = doubleArrayOf(0.0, 0.0, 0.0, 0.0)
        var validPairs = 0
        for (pair in pairs) {
            var after: String? = null
            var pairHadData = false
            var guard = 0
            while (guard++ < 20000) {
                val page = runCatching { okx.historyTrades(pair, "2", after, 100) }.getOrNull()?.data.orEmpty()
                if (page.isEmpty()) break
                page.forEach { t ->
                    val ts = t.ts?.toLongOrNull() ?: return@forEach
                    if (ts >= cutoff && ts < System.currentTimeMillis() && t.side.equals("buy", true)) {
                        val qty = t.sz?.toDoubleOrNull() ?: return@forEach
                        if (qty.isFinite() && qty >= 0) {
                            val ageDays = (System.currentTimeMillis() - ts) / 86400000.0
                            if (ageDays < 1.0) totals[3] += qty
                            if (ageDays <= 3.0) totals[0] += qty
                            if (ageDays <= 5.0) totals[1] += qty
                            totals[2] += qty
                            pairHadData = true
                        }
                    }
                }
                val oldest = page.minOfOrNull { it.ts?.toLongOrNull() ?: Long.MAX_VALUE } ?: break
                if (oldest <= cutoff) break
                after = page.lastOrNull()?.tradeId ?: break
            }
            if (pairHadData) validPairs++
        }
        return if (validPairs > 0) SourceResult("OKX", totals, validPairs) else null
    }

    private suspend fun loadBybit(coin: String): SourceResult? {
        val quotes = stableQuotes
        // Bybit public endpoint is intentionally used for current-day coverage; it returns the taker side.
        val symbols = listOf("USDT", "USDC").flatMap { q -> listOf("${coin.uppercase(Locale.US)}$q") }.distinct()
        val totals = doubleArrayOf(0.0,0.0,0.0,0.0); var pairs=0
        for (s in symbols) runCatching { bybit.recentTrade(symbol=s, limit=60) }.getOrNull()?.result?.list.orEmpty().forEach { t ->
            if (t.side.equals("Buy",true)) {
                val q=t.size?.toDoubleOrNull() ?: return@forEach; if (!q.isFinite()||q<0) return@forEach
                totals[3]+=q
            }
        }
        if (totals[3]>0) pairs=1
        return if(pairs>0) SourceResult("Bybit", totals,pairs) else null
    }

    private suspend fun loadBitget(coin: String): SourceResult? {
        val info=bitget.instruments("SPOT"); val pairs=info.data.orEmpty().filter{it.baseCoin.equals(coin,true)&&stableQuotes.contains(it.quoteCoin?.uppercase(Locale.US))&& !it.status.equals("offline",true)}.mapNotNull{it.symbol}.distinct()
        val totals=doubleArrayOf(0.0,0.0,0.0,0.0); var valid=0
        for(p in pairs) { val fills=runCatching{bitget.fills("SPOT",p,100)}.getOrNull()?.data.orEmpty(); var had=false; for(f in fills) if(f.side.equals("buy",true)){val q=f.size?.toDoubleOrNull()?:continue; if(q.isFinite()&&q>=0){totals[3]+=q;had=true}}; if(had) valid++ }
        return if(valid>0) SourceResult("Bitget",totals,valid) else null
    }

    private suspend fun loadGate(coin: String): SourceResult? {
        val pairs=gate.currencyPairs().filter{it.base.equals(coin,true)&&stableQuotes.contains(it.quote?.uppercase(Locale.US))&& !it.tradeStatus.equals("untradable",true)}.mapNotNull{it.id}.distinct()
        val totals=doubleArrayOf(0.0,0.0,0.0,0.0); var valid=0; val dayStart=System.currentTimeMillis()-86400000L
        for(p in pairs){val trades=runCatching{gate.trades(p,1000)}.getOrNull().orEmpty();var had=false;for(t in trades){if(t.side.equals("buy",true)){val q=t.amount?.toDoubleOrNull()?:continue;val ts=t.create_time_ms?.toDoubleOrNull()?.toLong()?:((t.create_time_ms?.toDoubleOrNull()?:0.0)*1000).toLong();if(q.isFinite()&&q>=0&&ts>=dayStart){totals[3]+=q;had=true}}};if(had)valid++}
        return if(valid>0)SourceResult("Gate.io",totals,valid)else null
    }

    private suspend fun loadCoinEx(coin: String): SourceResult? {
        val markets=runCatching{coinex.marketList()}.getOrNull()?.data.orEmpty().filter{it.base_ccy.equals(coin,true)&&stableQuotes.contains(it.quote_ccy?.uppercase(Locale.US))}.mapNotNull{it.market}.distinct()
        val totals=doubleArrayOf(0.0,0.0,0.0,0.0);var valid=0
        // CoinEx daily ticker exposes taker buy volume for the current 24h trading-day window.
        for(m in markets){val row=runCatching{coinex.ticker(m)}.getOrNull()?.data?.firstOrNull();val q=row?.volume_buy?.toDoubleOrNull();if(q!=null&&q.isFinite()&&q>=0){totals[3]+=q;valid++}}
        return if(valid>0)SourceResult("CoinEx",totals,valid)else null
    }

    private suspend fun loadDexToday(coin: String): SourceResult? {
        // GeckoTerminal is a broad on-chain index (1,500+ DEXs / 200+ networks). We use its top pools
        // for the requested symbol and count only swaps where the token is the asset received.
        val found=runCatching{gecko.searchPools(coin.uppercase(Locale.US),1)}.getOrNull()?.data.orEmpty().take(20)
        if(found.isEmpty()) return null
        var buy=0.0; var valid=0; val since=System.currentTimeMillis()-86400000L
        for(d in found){
            val parts=d.id?.split("_")?:continue; if(parts.size<2)continue; val network=parts[0]; val pool=parts[1]
            val trades=runCatching{gecko.trades(network,pool,1)}.getOrNull()?.data.orEmpty()
            var had=false
            for(t in trades){
                val a=t.attributes?:continue; val ts=runCatching{java.time.Instant.parse(a.get("block_timestamp")?.asString).toEpochMilli()}.getOrNull()?:continue
                if(ts<since)continue
                val kind=a.get("kind")?.asString?.lowercase(Locale.US)
                if(kind=="buy"||kind=="swap"){
                    val toAmt=a.get("to_token_amount")?.asString?.toDoubleOrNull()
                    if(toAmt!=null&&toAmt.isFinite()&&toAmt>=0){buy+=toAmt;had=true}
                }
            }
            if(had)valid++
        }
        return if(valid>0)SourceResult("DEX",doubleArrayOf(0.0,0.0,0.0,buy),valid)else null
    }

}

@Composable
fun App(vm: SpotViewModel = viewModel()) {
    var settings by remember { mutableStateOf(false) }
    val background = androidx.compose.ui.graphics.Color(0xFF061426)
    val surface = androidx.compose.ui.graphics.Color(0xFF0B1D35)
    val primary = androidx.compose.ui.graphics.Color(0xFF19D9B0)
    val secondary = androidx.compose.ui.graphics.Color(0xFF3C8DFF)
    val text = androidx.compose.ui.graphics.Color(0xFFF2F6FF)
    val muted = androidx.compose.ui.graphics.Color(0xFFA9BCD8)
    val scheme = darkColorScheme(primary = primary, secondary = secondary, background = background, surface = surface, onBackground = text, onSurface = text, onSurfaceVariant = muted)
    MaterialTheme(colorScheme = scheme) {
        if (settings) SettingsScreen(vm, { settings = false }, background, surface, primary, text, muted)
        else {
            val supply = vm.circulatingSupply
            val windows = listOf(Triple("3D", vm.buy3d, supply), Triple("5D", vm.buy5d, supply), Triple("7D", vm.buy7d, supply))
            Scaffold(containerColor = background, bottomBar = {
                NavigationBar(containerColor = background) {
                    NavigationBarItem(true, {}, icon = { Text("⌂") }, label = { Text("Home") })
                    NavigationBarItem(false, {}, icon = { Text("⌕") }, label = { Text("Search") })
                    NavigationBarItem(false, {}, icon = { Text("▣") }, label = { Text("History") })
                    NavigationBarItem(false, { settings = true }, icon = { Text("⚙") }, label = { Text("Settings") })
                }
            }) { padding ->
                LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Surface(shape = MaterialTheme.shapes.large, color = secondary.copy(alpha = .16f)) {
                                Image(painterResource(com.example.spotvolume.R.drawable.ic_anteater_foreground), contentDescription = "Anteater", modifier = Modifier.size(48.dp).padding(5.dp))
                            }
                            Column(Modifier.weight(1f)) { Text("Anteater", style = MaterialTheme.typography.headlineSmall, color = text); Text("Global Spot Accumulation • CEX + DEX • Spot Only", color = muted, style = MaterialTheme.typography.bodySmall) }
                            TextButton({ settings = true }) { Text("⚙") }
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(vm.symbol, { vm.symbol = it.uppercase(Locale.US) }, placeholder = { Text("Enter coin, e.g. BTC") }, singleLine = true, modifier = Modifier.weight(1f), leadingIcon = { Text("⌕") })
                            Button({ vm.load() }, enabled = !vm.loading && !vm.autoScanning, modifier = Modifier.height(56.dp)) { Text(if (vm.loading) "Loading…" else "Calculate") }
                        }
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Column(Modifier.weight(1f)) {
                                        Text("AUTO SCAN — CEX + DEX NET ACCUMULATION", style = MaterialTheme.typography.titleMedium)
                                        Text(if (vm.continuousScanEnabled) "AUTO SCAN: ON • every ${vm.scanIntervalMinutes} min" else "AUTO SCAN: OFF", color = primary, style = MaterialTheme.typography.bodySmall)
                                        Text("Discovers Spot flow, verifies it across supported CEX + DEX sources, and reports Buy − Sell. Sources without reliable direction are excluded.", color = muted, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Button({ vm.autoScan() }, enabled = !vm.loading && !vm.autoScanning) { Text(if (vm.autoScanning) "Scanning…" else "Auto Scan") }
                                }
                                if (vm.autoScanning || vm.autoScanStatus.isNotBlank()) Text(vm.autoScanStatus, color = muted, style = MaterialTheme.typography.bodySmall)
                                Text("Found: ${vm.autoScanFound}", color = primary, style = MaterialTheme.typography.titleMedium)
                                vm.autoScanResults.take(50).forEachIndexed { index, row ->
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Text("${index + 1}", modifier = Modifier.width(34.dp), color = muted)
                                        Column(Modifier.weight(1f)) {
                                            Text(row.symbol, style = MaterialTheme.typography.titleMedium)
                                            Text("Buy ${compact(row.buy)} • Sell ${compact(row.sell)} • Net ${compact(row.net)} ${row.symbol}", color = muted, style = MaterialTheme.typography.bodySmall)
                                            Text(row.exchanges, color = muted, style = MaterialTheme.typography.bodySmall)
                                        }
                                        Column(horizontalAlignment = Alignment.End) { Text("${row.ratioPct.format1()}%", color = primary, style = MaterialTheme.typography.titleMedium); row.tradingViewUrl?.let { Text("TradingView ↗", color = secondary, style = MaterialTheme.typography.bodySmall) } }
                                    }
                                    if (index < vm.autoScanResults.take(50).lastIndex) HorizontalDivider(color = secondary.copy(alpha = .12f))
                                }
                                if (vm.autoScanResults.size > 50) Text("Showing first 50 of ${vm.autoScanResults.size} found assets, sorted by Buy / circulating supply.", color = muted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    vm.error?.let { msg -> item { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) { Text(msg, Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onErrorContainer) } } }
                    item { Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (vm.continuousScanEnabled) "AUTO SCAN: ON" else "AUTO SCAN: OFF", style = MaterialTheme.typography.titleLarge, color = if (vm.continuousScanEnabled) primary else muted)
                        Text(if (vm.continuousScanEnabled) "Background scan every ${vm.scanIntervalMinutes} minutes" else "Enable automatic background scanning in Settings", color = muted, style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button({ vm.scanNow() }, enabled = !vm.loading && !vm.autoScanning) { Text("Scan Now") }
                            OutlinedButton({ vm.saveScanSettings(vm.scanIntervalMinutes, !vm.continuousScanEnabled) }) { Text(if (vm.continuousScanEnabled) "Disable" else "Enable") }
                        }
                        if (vm.autoScanStatus.isNotBlank()) Text(vm.autoScanStatus, color = muted, style = MaterialTheme.typography.bodySmall)
                    } } }
                    item { Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Current Circulating Supply", color = muted); Text(supply?.let { compact(it) + " ${vm.symbol}" } ?: "—", style = MaterialTheme.typography.headlineMedium); Text("Current supply is the denominator for all three windows.", color = muted, style = MaterialTheme.typography.bodySmall) } } }
                    item { Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("DAILY BUY — PRIMARY", style = MaterialTheme.typography.titleLarge)
                        Text("Current-day Spot buy demand from every verified source returned by the app.", color = muted, style = MaterialTheme.typography.bodySmall)
                        val dpct=if(vm.dailyBuy!=null&&supply!=null&&supply!!>0)vm.dailyBuy!!/supply!!*100 else null
                        Text("CEX Buy: ${vm.dailyCexBuy?.let{compact(it)+" "+vm.symbol}?:"—"}")
                        Text("DEX Buy: ${vm.dailyDexBuy?.let{compact(it)+" "+vm.symbol}?:"—"}")
                        Text("TOTAL BUY: ${vm.dailyBuy?.let{compact(it)+" "+vm.symbol}?:"—"}", style = MaterialTheme.typography.headlineSmall, color = primary)
                        Text("Total / circulating supply: ${dpct?.let{it.format1()+"%"}?:"—"}", color=muted)
                        Text("Verified sources: ${vm.dailySourceCount}", color=muted, style=MaterialTheme.typography.bodySmall)
                    } } }
                    item { Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("NET SPOT ACCUMULATION — PRIMARY SIGNAL", style = MaterialTheme.typography.titleMedium)
                        Text("Buy minus Sell across verified Spot CEX + DEX sources. Positive net means more token quantity was bought than sold in the measured window.", color = muted, style = MaterialTheme.typography.bodySmall)
                        Text("Buy: ${vm.dailyBuy?.let{compact(it)+" "+vm.symbol} ?: "—"}")
                        Text("Sell: ${vm.dailySell?.let{compact(it)+" "+vm.symbol} ?: "—"}")
                        Text("NET: ${vm.dailyNet?.let{(if(it>=0) "+" else "")+compact(it)+" "+vm.symbol} ?: "—"}", style = MaterialTheme.typography.headlineSmall, color = primary)
                        Text("Net / circulating supply: ${vm.netRatioPct?.let{it.format1()+"%"} ?: "—"}", color = muted)
                    } } }
                    item { Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("TODAY vs RECENT BASELINE", style = MaterialTheme.typography.titleMedium)
                        Text("Statistical-style intensity check using this token's own recent daily buy rate. It does not filter out signals; it only describes how unusual today is.", color = muted, style = MaterialTheme.typography.bodySmall)
                        Text(if (vm.anomalyMultiple != null) "Today is ${vm.anomalyMultiple!!.format1()}× the median daily buy rate of the previous 2/4/6 days." else "Insufficient verified multi-day data for a baseline.")
                        Text(if (vm.anomalyDeltaPct != null) "Deviation from recent baseline: ${vm.anomalyDeltaPct!!.format1()}%" else "—", color = primary)
                        Text("This is a relative anomaly indicator, not a fixed Buy/Supply threshold.", color = muted, style = MaterialTheme.typography.bodySmall)
                    } } }
                    item { Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("MULTI-DAY BUY — SECONDARY", style = MaterialTheme.typography.titleLarge)
                        Text("3D, 5D and 7D accumulation. Daily Buy remains separate.", color = muted, style = MaterialTheme.typography.bodySmall)
                        windows.forEach { (label, buy, circ) ->
                            val pct = if (buy != null && circ != null && circ > 0) buy / circ * 100.0 else null
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, modifier = Modifier.width(46.dp), color = primary, style = MaterialTheme.typography.titleMedium); Column(Modifier.weight(1f)) { Text(if (buy != null) "Buy volume: ${compact(buy)} ${vm.symbol}" else "Buy volume: unavailable"); Text(if (pct != null) "${pct.format1()}% of circulating supply" else "Insufficient verified data", color = muted, style = MaterialTheme.typography.bodySmall) } }
                            if (label != "7D") HorizontalDivider(color = secondary.copy(alpha = .12f))
                        }
                    } } }
                    item { Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("Data Quality", style = MaterialTheme.typography.titleMedium); Text("${vm.sourceCount} CEX source(s) returned usable Spot buy data; ${vm.dailySourceCount} total verified sources are counted for today.", color = text); Text(vm.sourceNote.ifBlank { "No source checked yet." }, color = muted, style = MaterialTheme.typography.bodySmall); Text("Important: taker-buy volume is a demand-side proxy, not proof of net new capital or long-term holding.", color = muted, style = MaterialTheme.typography.bodySmall) } } }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: SpotViewModel, onBack: () -> Unit, background: androidx.compose.ui.graphics.Color, surface: androidx.compose.ui.graphics.Color, primary: androidx.compose.ui.graphics.Color, text: androidx.compose.ui.graphics.Color, muted: androidx.compose.ui.graphics.Color) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { TextButton(onBack) { Text("Back") }; Text("Settings", style = MaterialTheme.typography.headlineSmall, color = text) }
        Text("CoinMarketCap API key (optional)", color = text)
        OutlinedTextField(vm.apiKey, { vm.apiKey = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), placeholder = { Text("Optional: paste your CMC key") })
        Button({ vm.saveKey() }, modifier = Modifier.fillMaxWidth()) { Text("Save") }

        Text("Automatic scan interval", color = text, style = MaterialTheme.typography.titleMedium)
        var interval by remember(vm.scanIntervalMinutes) { mutableStateOf(vm.scanIntervalMinutes.toString()) }
        OutlinedTextField(
            value = interval,
            onValueChange = { interval = it.filter(Char::isDigit).take(2) },
            singleLine = true,
            label = { Text("Minutes") },
            supportingText = { Text("Default: 5 minutes. Allowed: 1–60 minutes.") },
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Button({
                val m = interval.toIntOrNull()?.coerceIn(1, 60) ?: 5
                interval = m.toString()
                vm.saveScanSettings(m, true)
            }) { Text("Save & Enable") }
            OutlinedButton({ vm.saveScanSettings(interval.toIntOrNull()?.coerceIn(1, 60) ?: 5, false) }) { Text("Disable") }
        }
        Button({ vm.scanNow() }, modifier = Modifier.fillMaxWidth(), enabled = !vm.loading && !vm.autoScanning) { Text("Scan Now") }
        Text("Background scanning", color = text, style = MaterialTheme.typography.titleMedium)
        Text("When enabled, Anteater keeps a foreground service running and scans on the selected interval. Android may show a persistent service notification.", color = muted, style = MaterialTheme.typography.bodySmall)
        Text(
            if (vm.continuousScanEnabled) "Automatic scan is ON. It continues in the background every ${vm.scanIntervalMinutes} minute(s), including when the app is closed." else "Automatic scan is OFF. Scan Now still runs an immediate scan.",
            color = muted, style = MaterialTheme.typography.bodySmall
        )

        Card(colors = CardDefaults.cardColors(containerColor = surface)) { Text("CoinGlass is not used in this build. Direct public CEX market-data endpoints are used for the accumulation numerator; CMC is optional for current circulating supply; without a key, the app falls back to CoinPaprika.", Modifier.padding(16.dp), color = muted) }
    }
}


class AnteaterScanService : Service() {
    private var job: Job? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(2000, serviceNotification("Anteater automatic scan is running"))
        job = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            while (isActive) {
                val prefs = getSharedPreferences("spot_volume", 0)
                if (!prefs.getBoolean("continuous_scan_enabled", false)) break

                // IMPORTANT: wait for the real scan Job to finish.
                // The previous implementation started autoScan() and immediately
                // entered the interval timer, so scans could overlap or be skipped.
                val vm = SpotViewModel(application)
                val scanJob = vm.autoScan()
                if (scanJob != null) {
                    scanJob.join()
                } else {
                    // If another scan is already active, give it a moment before
                    // starting the next service cycle.
                    delay(1000)
                }

                if (!isActive) break
                if (!prefs.getBoolean("continuous_scan_enabled", false)) break

                val mins = prefs.getInt("scan_interval_minutes", 5).coerceIn(1, 60)
                delay(mins * 60_000L)
            }
        }
    }
    private fun createChannel(){ if(Build.VERSION.SDK_INT>=26){ val m=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager; m.createNotificationChannel(NotificationChannel("anteater_service","Anteater Background Scan",NotificationManager.IMPORTANCE_LOW)) } }
    private fun serviceNotification(text:String)=NotificationCompat.Builder(this,"anteater_service").setSmallIcon(R.drawable.ic_stat_anteater).setContentTitle("Anteater").setContentText(text).setOngoing(true).build()
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int { return START_STICKY }
    override fun onDestroy(){ job?.cancel(); super.onDestroy() }
    override fun onBind(intent:Intent?):IBinder?=null
}
class AnteaterBootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val prefs = context.getSharedPreferences("spot_volume", 0)
        if (!prefs.getBoolean("continuous_scan_enabled", true)) return
        val serviceIntent = Intent(context, AnteaterScanService::class.java)
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(serviceIntent) else context.startService(serviceIntent)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if(Build.VERSION.SDK_INT>=33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 7001)
        // Anteater automatic scanning is ON by default.
        // One-time v23 migration guarantees upgraded installs receive the intended defaults.
        val prefs = getSharedPreferences("spot_volume", MODE_PRIVATE)
        if (!prefs.getBoolean("anteater_v23_initialized", false)) {
            prefs.edit()
                .putInt("scan_interval_minutes", 5)
                .putBoolean("continuous_scan_enabled", true)
                .putBoolean("anteater_v23_initialized", true)
                .apply()
        } else if (!prefs.contains("scan_interval_minutes")) {
            prefs.edit().putInt("scan_interval_minutes", 5).apply()
        }
        setContent { App() }
        if (prefs.getBoolean("continuous_scan_enabled", true)) {
            val serviceIntent = Intent(this, AnteaterScanService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
        }
    }
}
