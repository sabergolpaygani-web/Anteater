# Anteater v24

Android Spot Accumulation Scanner.

Build target: Android 36, Java 17, Gradle 8.13.
