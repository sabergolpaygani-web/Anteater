Anteater v26

Upload Anteater_24_FINAL.zip to the repository root.
Also place the included .github/workflows/build-apk.yml at the repository root under .github/workflows/build-apk.yml.
The workflow does not use android-actions/setup-android, so it avoids the failing SDK setup step seen in build #44.
It installs/updates Android platform 36 and build-tools 36.0.0 directly with the runner's sdkmanager, then builds and releases Anteater-v26.apk.
