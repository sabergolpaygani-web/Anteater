package com.example.spotvolume

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.gson.annotations.SerializedName
import com.google.gson.JsonObject
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query
import java.text.NumberFormat
import java.util.Locale

// v13: Daily Buy is the primary metric. Multi-day 3D/5D/7D is secondary.
// Core numerator = Spot taker-buy base-asset quantity. DEX is estimated from on-chain swap trades via GeckoTerminal; derivatives are excluded.

data class CmcStatus(@SerializedName("error_code") val errorCode: Int, @SerializedName("error_message") val errorMessage: String?)
data class CmcResponse(val data: CmcData?, val status: CmcStatus?)
data class CmcData(val marketPairs: List<CmcMarketPair>?)
data class CmcExchange(val name: String?)
data class CmcUsdQuote(@SerializedName("volume_24h") val volume24h: Double?)
data class CmcQuote(val USD: CmcUsdQuote?)
data class CmcMarketPair(val exchange: CmcExchange?, @SerializedName("market_id") val marketId: Long?, @SerializedName("market_pair") val marketPair: String?, val category: String?, val quote: CmcQuote?)

data class CmcSupplyResponse(val data: List<CmcSupplyAsset>?, val status: CmcStatus?)
data class CmcSupplyAsset(val symbol: String?, @SerializedName("circulating_supply") val circulatingSupply: Double?, @SerializedName("total_supply") val totalSupply: Double?)

interface CmcApi { @GET("v2/cryptocurrency/info") suspend fun info(@Query("symbol") symbol: String, @Header("X-CMC_PRO_API_KEY") key: String): CmcSupplyResponse }

// Binance Spot
interface BinanceApi {
    @GET("api/v3/exchangeInfo") suspend fun exchangeInfo(): BinanceExchangeInfo
    @GET("api/v3/klines") suspend fun klines(@Query("symbol") symbol: String, @Query("interval") interval: String = "1d", @Query("limit") limit: Int = 8): List<List<com.google.gson.JsonElement>>
}
data class BinanceExchangeInfo(val symbols: List<BinanceSymbol>?)
data class BinanceSymbol(val symbol: String?, val status: String?, val baseAsset: String?, val quoteAsset: String?)

// MEXC Spot. Its public Spot kline schema follows the same Binance-style 12-field layout,
// including takerBuyBaseVolume at index 9. The adapter is intentionally limited to Spot symbols.
interface MexcApi {
    @GET("api/v3/exchangeInfo") suspend fun exchangeInfo(): MexcExchangeInfo
    @GET("api/v3/aggTrades") suspend fun aggTrades(
        @Query("symbol") symbol: String,
        @Query("startTime") startTime: Long? = null,
        @Query("endTime") endTime: Long? = null,
        @Query("fromId") fromId: Long? = null,
        @Query("limit") limit: Int = 1000
    ): List<List<com.google.gson.JsonElement>>
}
data class MexcExchangeInfo(val symbols: List<MexcSymbol>?)
data class MexcSymbol(val symbol: String?, val status: String?, val baseAsset: String?, val quoteAsset: String?)

// OKX public Spot market history. The API explicitly labels side as the taker side.
interface OkxApi {
    @GET("api/v5/public/instruments") suspend fun instruments(@Query("instType") instType: String = "SPOT"): OkxInstrumentsResponse
    @GET("api/v5/market/history-trades") suspend fun historyTrades(
        @Query("instId") instId: String,
        @Query("type") type: String = "2",
        @Query("after") after: String? = null,
        @Query("limit") limit: Int = 100
    ): OkxTradesResponse
}
data class OkxInstrumentsResponse(val code: String?, val data: List<OkxInstrument>?)
data class OkxInstrument(val instId: String?, val baseCcy: String?, val quoteCcy: String?, val state: String?)
data class OkxTradesResponse(val code: String?, val data: List<OkxTrade>?)
data class OkxTrade(val instId: String?, val side: String?, val sz: String?, val tradeId: String?, val ts: String?)

data class SourceResult(val name: String, val values: DoubleArray, val pairs: Int)

// Bybit Spot public trades: side is the taker side.
interface BybitApi {
    @GET("v5/market/recent-trade") suspend fun recentTrade(@Query("category") category: String = "spot", @Query("symbol") symbol: String, @Query("limit") limit: Int = 60): BybitResponse
}
data class BybitResponse(val retCode: Int?, val result: BybitResult?)
data class BybitResult(val list: List<BybitTrade>?)
data class BybitTrade(val price: String?, val size: String?, val side: String?, val time: String?)

interface BitgetApi {
    @GET("api/v3/market/fills") suspend fun fills(@Query("category") category: String = "SPOT", @Query("symbol") symbol: String, @Query("limit") limit: Int = 100): BitgetResponse
    @GET("api/v3/market/instruments") suspend fun instruments(@Query("category") category: String = "SPOT"): BitgetInstrumentsResponse
}
data class BitgetResponse(val code: String?, val data: List<BitgetFill>?)
data class BitgetFill(val size: String?, val side: String?, val ts: String?)
data class BitgetInstrumentsResponse(val code: String?, val data: List<BitgetInstrument>?)
data class BitgetInstrument(val symbol: String?, val baseCoin: String?, val quoteCoin: String?, val status: String?)

interface GateApi {
    @GET("api/v4/spot/currency_pairs") suspend fun currencyPairs(): List<GatePair>
    @GET("api/v4/spot/trades") suspend fun trades(@Query("currency_pair") pair: String, @Query("limit") limit: Int = 1000): List<GateTrade>
}
data class GatePair(val id: String?, val base: String?, val quote: String?, val tradeStatus: String?)
data class GateTrade(val id: String?, val create_time_ms: String?, val side: String?, val amount: String?)

interface CoinExApi {
    @GET("v2/spot/market/ticker") suspend fun ticker(@Query("market") market: String? = null): CoinExTickerResponse
    @GET("v2/spot/market") suspend fun marketList(): CoinExMarketsResponse
}
data class CoinExTickerResponse(val code: Int?, val data: List<CoinExTicker>?)
data class CoinExTicker(val market: String?, val volume_buy: String?, val period: Int?)
data class CoinExMarketsResponse(val code: Int?, val data: List<CoinExMarket>?)
data class CoinExMarket(val market: String?, val base_ccy: String?, val quote_ccy: String?)

// GeckoTerminal public on-chain DEX data. Public API is unauthenticated and currently rate-limited.
interface GeckoApi {
    @GET("api/v2/search/pools") suspend fun searchPools(@Query("query") query: String, @Query("page") page: Int = 1): GeckoSearchResponse
    @GET("api/v2/networks/{network}/pools/{pool}/trades") suspend fun trades(@retrofit2.http.Path("network") network: String, @retrofit2.http.Path("pool") pool: String, @Query("page") page: Int = 1): GeckoTradesResponse
}
data class GeckoSearchResponse(val data: List<GeckoData>?)
data class GeckoTradesResponse(val data: List<GeckoData>?)
data class GeckoData(val id: String?, val type: String?, val attributes: JsonObject?)


private val stableQuotes = setOf("USDT", "USDC", "FDUSD", "USD")
private fun compact(value: Double): String = when {
    value >= 1e12 -> "${(value / 1e12).format1()}T"
    value >= 1e9 -> "${(value / 1e9).format1()}B"
    value >= 1e6 -> "${(value / 1e6).format1()}M"
    value >= 1e3 -> "${(value / 1e3).format1()}K"
    else -> value.format1()
}
private fun Double.format1(): String = String.format(Locale.US, "%.1f", this)

class SpotViewModel(application: Application) : AndroidViewModel(application) {
    var symbol by mutableStateOf("BTC")
    var apiKey by mutableStateOf("")
    var loading by mutableStateOf(false)
    var statusText by mutableStateOf("")
    var error by mutableStateOf<String?>(null)
    var circulatingSupply by mutableStateOf<Double?>(null)
    var totalSupply by mutableStateOf<Double?>(null)
    var dailyBuy by mutableStateOf<Double?>(null)
    var dailyCexBuy by mutableStateOf<Double?>(null)
    var dailyDexBuy by mutableStateOf<Double?>(null)
    var dailySourceCount by mutableStateOf(0)
    var buy3d by mutableStateOf<Double?>(null)
    var buy5d by mutableStateOf<Double?>(null)
    var buy7d by mutableStateOf<Double?>(null)
    var sourceCount by mutableStateOf(0)
    var sourceNote by mutableStateOf("")
    var anomalyMultiple by mutableStateOf<Double?>(null)
    var anomalyDeltaPct by mutableStateOf<Double?>(null)

    private val prefs = application.applicationContext.getSharedPreferences("spot_volume", 0)
    private val cmc = Retrofit.Builder().baseUrl("https://pro-api.coinmarketcap.com/").addConverterFactory(GsonConverterFactory.create()).build().create(CmcApi::class.java)
    private val binance = Retrofit.Builder().baseUrl("https://data-api.binance.vision/").addConverterFactory(GsonConverterFactory.create()).build().create(BinanceApi::class.java)
    private val mexc = Retrofit.Builder().baseUrl("https://api.mexc.com/").addConverterFactory(GsonConverterFactory.create()).build().create(MexcApi::class.java)
    private val okx = Retrofit.Builder().baseUrl("https://www.okx.com/").addConverterFactory(GsonConverterFactory.create()).build().create(OkxApi::class.java)
    private val bybit = Retrofit.Builder().baseUrl("https://api.bybit.com/").addConverterFactory(GsonConverterFactory.create()).build().create(BybitApi::class.java)
    private val bitget = Retrofit.Builder().baseUrl("https://api.bitget.com/").addConverterFactory(GsonConverterFactory.create()).build().create(BitgetApi::class.java)
    private val gate = Retrofit.Builder().baseUrl("https://api.gateio.ws/").addConverterFactory(GsonConverterFactory.create()).build().create(GateApi::class.java)
    private val coinex = Retrofit.Builder().baseUrl("https://api.coinex.com/").addConverterFactory(GsonConverterFactory.create()).build().create(CoinExApi::class.java)
    private val gecko = Retrofit.Builder().baseUrl("https://api.geckoterminal.com/").addConverterFactory(GsonConverterFactory.create()).build().create(GeckoApi::class.java)

    init { apiKey = prefs.getString("api_key", "") ?: "" }
    fun saveKey() { prefs.edit().putString("api_key", apiKey.trim()).apply() }

    fun load() {
        saveKey()
        if (apiKey.isBlank()) { error = "Enter your CoinMarketCap API key in Settings."; return }
        val coin = symbol.trim().uppercase(Locale.US)
        if (coin.isBlank()) { error = "Enter a crypto symbol."; return }
        viewModelScope.launch {
            loading = true; error = null; statusText = "Loading supply and verified CEX Spot buy data…"
            dailyBuy = null; dailyCexBuy = null; dailyDexBuy = null; dailySourceCount = 0; buy3d = null; buy5d = null; buy7d = null; circulatingSupply = null; totalSupply = null; sourceCount = 0; sourceNote = ""; anomalyMultiple = null; anomalyDeltaPct = null
            try {
                val supplyJob = async { loadSupply(coin) }
                val sourceJobs = listOf(
                    async { runCatching { loadBinance(coin) }.getOrNull() },
                    async { runCatching { loadMexc(coin) }.getOrNull() },
                    async { runCatching { loadOkx(coin) }.getOrNull() },
                    async { runCatching { loadBybit(coin) }.getOrNull() },
                    async { runCatching { loadBitget(coin) }.getOrNull() },
                    async { runCatching { loadGate(coin) }.getOrNull() },
                    async { runCatching { loadCoinEx(coin) }.getOrNull() }
                )
                val dexJob = async { runCatching { loadDexToday(coin) }.getOrNull() }
                val supply = supplyJob.await()
                val results = sourceJobs.awaitAll().filterNotNull()
                val dex = dexJob.await()
                circulatingSupply = supply.first
                totalSupply = supply.second
                val sums = doubleArrayOf(0.0, 0.0, 0.0)
                var count = 0
                results.forEach { r -> for (i in 0..2) sums[i] += r.values[i]; if (r.pairs > 0) count++ }
                buy3d = if (count > 0) sums[0] else null
                buy5d = if (count > 0) sums[1] else null
                buy7d = if (count > 0) sums[2] else null
                dailyCexBuy = results.sumOf { it.values[3].takeIf { v -> v.isFinite() && v >= 0 } ?: 0.0 }.takeIf { it > 0 }
                dailyDexBuy = dex?.values?.getOrNull(3)?.takeIf { it.isFinite() && it >= 0 }
                dailyBuy = listOfNotNull(dailyCexBuy, dailyDexBuy).takeIf { it.isNotEmpty() }?.sum()
                sourceCount = count
                dailySourceCount = count + if (dailyDexBuy != null) 1 else 0
                sourceNote = "CEX: ${results.joinToString { it.name }}${if (dailyDexBuy != null) "; DEX: GeckoTerminal top pools" else "; DEX: no verified data returned"}."
                if (dailyBuy != null && supply != null && supply > 0 && buy7d != null && buy7d!! > dailyBuy!! && buy5d != null && buy5d!! > dailyBuy!! && buy3d != null && buy3d!! > dailyBuy!!) {
                    val priorMeans = listOf(
                        (buy3d!! - dailyBuy!!) / 2.0,
                        (buy5d!! - dailyBuy!!) / 4.0,
                        (buy7d!! - dailyBuy!!) / 6.0
                    ).filter { it > 0 && it.isFinite() }
                    if (priorMeans.isNotEmpty()) {
                        val sorted = priorMeans.sorted()
                        val priorAvg = sorted[sorted.size / 2]
                        anomalyMultiple = dailyBuy!! / priorAvg
                        anomalyDeltaPct = (anomalyMultiple!! - 1.0) * 100.0
                    }
                }
                statusText = "Daily Buy is primary. CEX + DEX Spot only; multi-day is secondary."
            } catch (e: Exception) { error = e.message ?: "Network error." }
            finally { loading = false }
        }
    }

    private suspend fun loadSupply(coin: String): Pair<Double?, Double?> {
        val r = cmc.info(coin, apiKey.trim())
        if (r.status?.errorCode != 0) throw IllegalStateException(r.status?.errorMessage ?: "CoinMarketCap API error.")
        val a = r.data?.firstOrNull() ?: return null to null
        return a.circulatingSupply to a.totalSupply
    }

    private fun aggregate(rowsByPair: List<List<List<com.google.gson.JsonElement>>>): SourceResult? {
        val totals = doubleArrayOf(0.0, 0.0, 0.0, 0.0)
        var pairs = 0
        val now = System.currentTimeMillis()
        rowsByPair.forEach { rows ->
            val completed = rows.filter { row -> row.size > 9 && row[6].asLong < now }.takeLast(7)
            if (completed.isNotEmpty()) {
                pairs++
                val vals = completed.mapNotNull { it[9].asString.toDoubleOrNull()?.takeIf { x -> x.isFinite() && x >= 0.0 } }
                if (vals.isNotEmpty()) {
                    totals[3] += vals.last()
                    totals[0] += vals.takeLast(3).sum()
                    totals[1] += vals.takeLast(5).sum()
                    totals[2] += vals.takeLast(7).sum()
                }
            }
        }
        return if (pairs > 0) SourceResult("", totals, pairs) else null
    }

    private suspend fun loadBinance(coin: String): SourceResult? {
        val info = binance.exchangeInfo()
        val pairs = info.symbols.orEmpty().filter { it.status == "TRADING" && it.baseAsset.equals(coin, true) && stableQuotes.contains(it.quoteAsset?.uppercase(Locale.US)) }.mapNotNull { it.symbol }.distinct()
        val rows = pairs.map { p -> runCatching { binance.klines(p) }.getOrDefault(emptyList()) }
        return aggregate(rows)?.copy(name = "Binance")
    }

    private suspend fun loadMexc(coin: String): SourceResult? {
        val info = mexc.exchangeInfo()
        val pairs = info.symbols.orEmpty()
            .filter { it.status.equals("ENABLED", true) || it.status.equals("TRADING", true) }
            .filter { it.baseAsset.equals(coin, true) && stableQuotes.contains(it.quoteAsset?.uppercase(Locale.US)) }
            .mapNotNull { it.symbol }.distinct()

        // MEXC v3 klines do NOT expose taker-buy volume. Use aggregate trades instead:
        // m=true means buyer was maker, therefore !m is an aggressive/taker buy.
        val sevenDaysAgo = System.currentTimeMillis() - 7L * 24L * 60L * 60L * 1000L
        val totals = doubleArrayOf(0.0, 0.0, 0.0, 0.0)
        var validPairs = 0
        for (pair in pairs) {
            var cursor = sevenDaysAgo
            var pairHadData = false
            var guard = 0
            while (cursor < System.currentTimeMillis() && guard++ < 20000) {
                val end = minOf(System.currentTimeMillis(), cursor + 6L * 60L * 60L * 1000L)
                var fromId: Long? = null
                var pageGuard = 0
                var finishedWindow = false
                while (!finishedWindow && pageGuard++ < 20000) {
                    val rows = runCatching { mexc.aggTrades(pair, if (fromId == null) cursor else null, if (fromId == null) end else null, fromId, 1000) }.getOrDefault(emptyList())
                    if (rows.isEmpty()) { finishedWindow = true; break }
                    rows.forEach { r ->
                        val ts = r[5].asLong
                        val qty = r[4].asString.toDoubleOrNull() ?: return@forEach
                        val isTakerBuy = !r[6].asBoolean
                        if (isTakerBuy && ts >= sevenDaysAgo && ts < System.currentTimeMillis() && qty.isFinite() && qty >= 0) {
                            val ageDays = (System.currentTimeMillis() - ts) / 86400000.0
                            if (ageDays < 1.0) totals[3] += qty
                            if (ageDays <= 3.0) totals[0] += qty
                            if (ageDays <= 5.0) totals[1] += qty
                            totals[2] += qty
                            pairHadData = true
                        }
                    }
                    val lastTs = rows.maxOfOrNull { it[5].asLong } ?: end
                    val lastId = rows.maxOfOrNull { it[0].asLong }
                    if (lastTs >= end || rows.size < 1000) {
                        finishedWindow = true
                    } else {
                        fromId = (lastId ?: Long.MAX_VALUE) + 1L
                    }
                }
                cursor = end + 1
            }
            if (pairHadData) validPairs++
        }
        return if (validPairs > 0) SourceResult("MEXC", totals, validPairs) else null
    }

    private suspend fun loadOkx(coin: String): SourceResult? {
        val info = okx.instruments("SPOT")
        val pairs = info.data.orEmpty()
            .filter { it.state.equals("live", true) && it.baseCcy.equals(coin, true) && stableQuotes.contains(it.quoteCcy?.uppercase(Locale.US)) }
            .mapNotNull { it.instId }.distinct()

        val cutoff = System.currentTimeMillis() - 7L * 24L * 60L * 60L * 1000L
        val totals = doubleArrayOf(0.0, 0.0, 0.0, 0.0)
        var validPairs = 0
        for (pair in pairs) {
            var after: String? = null
            var pairHadData = false
            var guard = 0
            while (guard++ < 20000) {
                val page = runCatching { okx.historyTrades(pair, "2", after, 100) }.getOrNull()?.data.orEmpty()
                if (page.isEmpty()) break
                page.forEach { t ->
                    val ts = t.ts?.toLongOrNull() ?: return@forEach
                    if (ts >= cutoff && ts < System.currentTimeMillis() && t.side.equals("buy", true)) {
                        val qty = t.sz?.toDoubleOrNull() ?: return@forEach
                        if (qty.isFinite() && qty >= 0) {
                            val ageDays = (System.currentTimeMillis() - ts) / 86400000.0
                            if (ageDays < 1.0) totals[3] += qty
                            if (ageDays <= 3.0) totals[0] += qty
                            if (ageDays <= 5.0) totals[1] += qty
                            totals[2] += qty
                            pairHadData = true
                        }
                    }
                }
                val oldest = page.minOfOrNull { it.ts?.toLongOrNull() ?: Long.MAX_VALUE } ?: break
                if (oldest <= cutoff) break
                after = page.lastOrNull()?.tradeId ?: break
            }
            if (pairHadData) validPairs++
        }
        return if (validPairs > 0) SourceResult("OKX", totals, validPairs) else null
    }

    private suspend fun loadBybit(coin: String): SourceResult? {
        val quotes = stableQuotes
        // Bybit public endpoint is intentionally used for current-day coverage; it returns the taker side.
        val symbols = listOf("USDT", "USDC").flatMap { q -> listOf("${coin.uppercase(Locale.US)}$q") }.distinct()
        val totals = doubleArrayOf(0.0,0.0,0.0,0.0); var pairs=0
        for (s in symbols) runCatching { bybit.recentTrade(symbol=s, limit=60) }.getOrNull()?.result?.list.orEmpty().forEach { t ->
            if (t.side.equals("Buy",true)) {
                val q=t.size?.toDoubleOrNull() ?: return@forEach; if (!q.isFinite()||q<0) return@forEach
                totals[3]+=q
            }
        }
        if (totals[3]>0) pairs=1
        return if(pairs>0) SourceResult("Bybit", totals,pairs) else null
    }

    private suspend fun loadBitget(coin: String): SourceResult? {
        val info=bitget.instruments("SPOT"); val pairs=info.data.orEmpty().filter{it.baseCoin.equals(coin,true)&&stableQuotes.contains(it.quoteCoin?.uppercase(Locale.US))&& !it.status.equals("offline",true)}.mapNotNull{it.symbol}.distinct()
        val totals=doubleArrayOf(0.0,0.0,0.0,0.0); var valid=0
        for(p in pairs) { val fills=runCatching{bitget.fills("SPOT",p,100)}.getOrNull()?.data.orEmpty(); var had=false; for(f in fills) if(f.side.equals("buy",true)){val q=f.size?.toDoubleOrNull()?:continue; if(q.isFinite()&&q>=0){totals[3]+=q;had=true}}; if(had) valid++ }
        return if(valid>0) SourceResult("Bitget",totals,valid) else null
    }

    private suspend fun loadGate(coin: String): SourceResult? {
        val pairs=gate.currencyPairs().filter{it.base.equals(coin,true)&&stableQuotes.contains(it.quote?.uppercase(Locale.US))&& !it.tradeStatus.equals("untradable",true)}.mapNotNull{it.id}.distinct()
        val totals=doubleArrayOf(0.0,0.0,0.0,0.0); var valid=0; val dayStart=System.currentTimeMillis()-86400000L
        for(p in pairs){val trades=runCatching{gate.trades(p,1000)}.getOrNull().orEmpty();var had=false;for(t in trades){if(t.side.equals("buy",true)){val q=t.amount?.toDoubleOrNull()?:continue;val ts=t.create_time_ms?.toDoubleOrNull()?.toLong()?:((t.create_time_ms?.toDoubleOrNull()?:0.0)*1000).toLong();if(q.isFinite()&&q>=0&&ts>=dayStart){totals[3]+=q;had=true}}};if(had)valid++}
        return if(valid>0)SourceResult("Gate.io",totals,valid)else null
    }

    private suspend fun loadCoinEx(coin: String): SourceResult? {
        val markets=runCatching{coinex.marketList()}.getOrNull()?.data.orEmpty().filter{it.base_ccy.equals(coin,true)&&stableQuotes.contains(it.quote_ccy?.uppercase(Locale.US))}.mapNotNull{it.market}.distinct()
        val totals=doubleArrayOf(0.0,0.0,0.0,0.0);var valid=0
        // CoinEx daily ticker exposes taker buy volume for the current 24h trading-day window.
        for(m in markets){val row=runCatching{coinex.ticker(m)}.getOrNull()?.data?.firstOrNull();val q=row?.volume_buy?.toDoubleOrNull();if(q!=null&&q.isFinite()&&q>=0){totals[3]+=q;valid++}}
        return if(valid>0)SourceResult("CoinEx",totals,valid)else null
    }

    private suspend fun loadDexToday(coin: String): SourceResult? {
        // GeckoTerminal is a broad on-chain index (1,500+ DEXs / 200+ networks). We use its top pools
        // for the requested symbol and count only swaps where the token is the asset received.
        val found=runCatching{gecko.searchPools(coin.uppercase(Locale.US),1)}.getOrNull()?.data.orEmpty().take(20)
        if(found.isEmpty()) return null
        var buy=0.0; var valid=0; val since=System.currentTimeMillis()-86400000L
        for(d in found){
            val parts=d.id?.split("_")?:continue; if(parts.size<2)continue; val network=parts[0]; val pool=parts[1]
            val trades=runCatching{gecko.trades(network,pool,1)}.getOrNull()?.data.orEmpty()
            var had=false
            for(t in trades){
                val a=t.attributes?:continue; val ts=runCatching{java.time.Instant.parse(a.get("block_timestamp")?.asString).toEpochMilli()}.getOrNull()?:continue
                if(ts<since)continue
                val kind=a.get("kind")?.asString?.lowercase(Locale.US)
                if(kind=="buy"||kind=="swap"){
                    val toAmt=a.get("to_token_amount")?.asString?.toDoubleOrNull()
                    if(toAmt!=null&&toAmt.isFinite()&&toAmt>=0){buy+=toAmt;had=true}
                }
            }
            if(had)valid++
        }
        return if(valid>0)SourceResult("DEX",doubleArrayOf(0.0,0.0,0.0,buy),valid)else null
    }

}

@Composable
fun App(vm: SpotViewModel = viewModel()) {
    var settings by remember { mutableStateOf(false) }
    val background = androidx.compose.ui.graphics.Color(0xFF061426)
    val surface = androidx.compose.ui.graphics.Color(0xFF0B1D35)
    val primary = androidx.compose.ui.graphics.Color(0xFF19D9B0)
    val secondary = androidx.compose.ui.graphics.Color(0xFF3C8DFF)
    val text = androidx.compose.ui.graphics.Color(0xFFF2F6FF)
    val muted = androidx.compose.ui.graphics.Color(0xFFA9BCD8)
    val scheme = darkColorScheme(primary = primary, secondary = secondary, background = background, surface = surface, onBackground = text, onSurface = text, onSurfaceVariant = muted)
    MaterialTheme(colorScheme = scheme) {
        if (settings) SettingsScreen(vm, { settings = false }, background, surface, primary, text, muted)
        else {
            val supply = vm.circulatingSupply
            val windows = listOf(Triple("3D", vm.buy3d, supply), Triple("5D", vm.buy5d, supply), Triple("7D", vm.buy7d, supply))
            Scaffold(containerColor = background, bottomBar = {
                NavigationBar(containerColor = background) {
                    NavigationBarItem(true, {}, icon = { Text("⌂") }, label = { Text("Home") })
                    NavigationBarItem(false, {}, icon = { Text("⌕") }, label = { Text("Search") })
                    NavigationBarItem(false, {}, icon = { Text("▣") }, label = { Text("History") })
                    NavigationBarItem(false, { settings = true }, icon = { Text("⚙") }, label = { Text("Settings") })
                }
            }) { padding ->
                LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Surface(shape = MaterialTheme.shapes.large, color = secondary.copy(alpha = .16f)) { Text("◎", Modifier.padding(10.dp), color = primary, style = MaterialTheme.typography.headlineSmall) }
                            Column(Modifier.weight(1f)) { Text("Global Spot Accumulation", style = MaterialTheme.typography.headlineSmall, color = text); Text("Daily Buy • CEX + DEX • Spot Only", color = muted, style = MaterialTheme.typography.bodySmall) }
                            TextButton({ settings = true }) { Text("⚙") }
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(vm.symbol, { vm.symbol = it.uppercase(Locale.US) }, placeholder = { Text("Enter coin, e.g. BTC") }, singleLine = true, modifier = Modifier.weight(1f), leadingIcon = { Text("⌕") })
                            Button({ vm.load() }, enabled = !vm.loading, modifier = Modifier.height(56.dp)) { Text(if (vm.loading) "Loading…" else "Calculate") }
                        }
                    }
                    vm.error?.let { msg -> item { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) { Text(msg, Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onErrorContainer) } } }
                    item { Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Current Circulating Supply", color = muted); Text(supply?.let { compact(it) + " ${vm.symbol}" } ?: "—", style = MaterialTheme.typography.headlineMedium); Text("Current supply is the denominator for all three windows.", color = muted, style = MaterialTheme.typography.bodySmall) } } }
                    item { Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("DAILY BUY — PRIMARY", style = MaterialTheme.typography.titleLarge)
                        Text("Current-day Spot buy demand from every verified source returned by the app.", color = muted, style = MaterialTheme.typography.bodySmall)
                        val dpct=if(vm.dailyBuy!=null&&supply!=null&&supply!!>0)vm.dailyBuy!!/supply!!*100 else null
                        Text("CEX Buy: ${vm.dailyCexBuy?.let{compact(it)+" "+vm.symbol}?:"—"}")
                        Text("DEX Buy: ${vm.dailyDexBuy?.let{compact(it)+" "+vm.symbol}?:"—"}")
                        Text("TOTAL BUY: ${vm.dailyBuy?.let{compact(it)+" "+vm.symbol}?:"—"}", style = MaterialTheme.typography.headlineSmall, color = primary)
                        Text("Total / circulating supply: ${dpct?.let{it.format1()+"%"}?:"—"}", color=muted)
                        Text("Verified sources: ${vm.dailySourceCount}", color=muted, style=MaterialTheme.typography.bodySmall)
                    } } }
                    item { Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("TODAY vs RECENT BASELINE", style = MaterialTheme.typography.titleMedium)
                        Text("Statistical-style intensity check using this token's own recent daily buy rate. It does not filter out signals; it only describes how unusual today is.", color = muted, style = MaterialTheme.typography.bodySmall)
                        Text(if (vm.anomalyMultiple != null) "Today is ${vm.anomalyMultiple!!.format1()}× the median daily buy rate of the previous 2/4/6 days." else "Insufficient verified multi-day data for a baseline.")
                        Text(if (vm.anomalyDeltaPct != null) "Deviation from recent baseline: ${vm.anomalyDeltaPct!!.format1()}%" else "—", color = primary)
                        Text("This is a relative anomaly indicator, not a fixed Buy/Supply threshold.", color = muted, style = MaterialTheme.typography.bodySmall)
                    } } }
                    item { Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("MULTI-DAY BUY — SECONDARY", style = MaterialTheme.typography.titleLarge)
                        Text("3D, 5D and 7D accumulation. Daily Buy remains separate.", color = muted, style = MaterialTheme.typography.bodySmall)
                        windows.forEach { (label, buy, circ) ->
                            val pct = if (buy != null && circ != null && circ > 0) buy / circ * 100.0 else null
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, modifier = Modifier.width(46.dp), color = primary, style = MaterialTheme.typography.titleMedium); Column(Modifier.weight(1f)) { Text(if (buy != null) "Buy volume: ${compact(buy)} ${vm.symbol}" else "Buy volume: unavailable"); Text(if (pct != null) "${pct.format1()}% of circulating supply" else "Insufficient verified data", color = muted, style = MaterialTheme.typography.bodySmall) } }
                            if (label != "7D") HorizontalDivider(color = secondary.copy(alpha = .12f))
                        }
                    } } }
                    item { Card(colors = CardDefaults.cardColors(containerColor = surface), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("Data Quality", style = MaterialTheme.typography.titleMedium); Text("${vm.sourceCount} CEX source(s) returned usable Spot buy data; ${vm.dailySourceCount} total verified sources are counted for today.", color = text); Text(vm.sourceNote.ifBlank { "No source checked yet." }, color = muted, style = MaterialTheme.typography.bodySmall); Text("Important: taker-buy volume is a demand-side proxy, not proof of net new capital or long-term holding.", color = muted, style = MaterialTheme.typography.bodySmall) } } }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: SpotViewModel, onBack: () -> Unit, background: androidx.compose.ui.graphics.Color, surface: androidx.compose.ui.graphics.Color, primary: androidx.compose.ui.graphics.Color, text: androidx.compose.ui.graphics.Color, muted: androidx.compose.ui.graphics.Color) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { TextButton(onBack) { Text("Back") }; Text("Settings", style = MaterialTheme.typography.headlineSmall, color = text) }
        Text("CoinMarketCap API key", color = text)
        OutlinedTextField(vm.apiKey, { vm.apiKey = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), placeholder = { Text("Paste your CMC key") })
        Button({ vm.saveKey() }, modifier = Modifier.fillMaxWidth()) { Text("Save") }
        Card(colors = CardDefaults.cardColors(containerColor = surface)) { Text("CoinGlass is not used in this build. Direct public CEX market-data endpoints are used for the accumulation numerator; CMC is used only for current circulating supply.", Modifier.padding(16.dp), color = muted) }
    }
}

class MainActivity : ComponentActivity() { override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App() } } }
